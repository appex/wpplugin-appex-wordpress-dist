== Changelog ==

= 1.3.1 =
fix: Removing WP Migrate moves its folder out of the plugins folder in one step and deletes the files after answering, so it can't stop halfway (1.3.0 could leave a half-deleted plugin). One action at a time per plugin, and an action finishes even if the dashboard stops waiting. Status reports commandsVersion 2.

= 1.3.0 =
feat: The WebCare dashboard can enable, disable or remove WP Migrate, and nothing else (POST /appex/v1/plugins, signed with its own key; enabling installs WP Migrate Pro from the dashboard where it's missing). The status endpoint also reports WP Migrate's push and pull settings and which actions the site supports.

= 1.2.1 =
feat: The plugin always updates itself automatically (no email to the site admin when it's the only update), and the update checker also loads on sites without ACF.

= 1.2.0 =
feat(status): Report whether search engines are discouraged from indexing the site (Settings > Reading).

= 1.1.0 =
feat(status): Report auto-update settings in the status endpoint: per plugin (and whether forced by code), WordPress core (major/minor/disabled) and whether the automatic updater is disabled.

= 1.0.99 =
feat(status): Add signed, read-only /wp-json/appex/v1/status endpoint reporting WordPress, PHP, theme and plugin versions and available updates for the WebCare dashboard.

= 1.0.98 =
security: Remove embedded GitHub token. Updates are now served from the public appex/wpplugin-appex-wordpress-dist repo and need no credentials.

= 1.0.97 =
fix(consent-banner): Fix consent mode issues by sending 'update' events after checking consent. Add consent check in head after Google Listings & Ads load.

= 1.0.96 =
feat(consent-banner): Add consent change functionality to Appex consent banner, with optional button in bottom of page

= 1.0.95 =
Fix: PHP-errors — undefined variable $pagenow

= 1.0.94 =
feat(discussion): add option to disable or enable comments for all posts

= 1.0.93 =
fix(consent-banner): check if certain fields are not empty before outputting CSS for the banner

= 1.0.92 =
chore: remove `add_meta_box` for page excerpts, use `add_post_type_support` instead

= 1.0.91 =
Fix: Change default cookie accept frequency to 365, as this is standard setting from Cookie Information

= 1.0.90 =
Add custom accept frequency and decline frequency fields for Cookie Information

= 1.0.89 =
fix: set default consent early for Appex Consent Banner

= 1.0.88 =
fix: run Appex Consent Banner code after ACF is fully initialized

= 1.0.87 =
Move consent banner to footer

= 1.0.86 =
Add feature Appex Consent Banner (beta) for Google consent

= 1.0.85 =
Add attribute for Google Consent Mode v2 in Cookie Information tag

= 1.0.84 =
Add option to remove Yoast SEO author tag

= 1.0.83 =
Update Looker Studio field name and decription to be more clear

= 1.0.82 =
Add option to paste in Looker Studio dashboard embed URL and have it visible in admin

= 1.0.81 =
Replace `{admin_email}` with custom admin email in `$notification['to']`, `$notification['toEmail']`, and `$notification['from']` instead of targeting the complete `$notification` array
(remake of 1.0.77 with modifications)

= 1.0.80 =
Add ability to change Gravity Forms CSV separator

= 1.0.79 =
Add custom language option for Cookie Information

= 1.0.78 =
Basically reverting to 1.0.76

= 1.0.77 =
Replace `{admin_email}` with custom admin email in `$notification['to']` instead of targeting the complete `$notification` array

= 1.0.76 =
Bugfix for privacy policy editing

= 1.0.75 =
Allow editors to edit privacy policy

= 1.0.74 =
Fixed Typekit script that failed when using PHP 8

= 1.0.73 =
Added option to add column in Gravity Forms list to show form usage info

= 1.0.72 =
Added shop_manager as available role to find suitable user administrator

= 1.0.71 =
Removed noscript tags for Google Tag Manager and Facebook Pixel

= 1.0.70 =
Add option page to GraphQL schema (if available)

= 1.0.69 =
Fix compatibility with Appex SMS login

= 1.0.68 =
Added filters to limit 2FA methods + force 2FA for admins + optionally enable 2FA for selected roles

= 1.0.67 =
Added filter to optionally block loading of all external scripts

= 1.0.66 =
Run ACF filter to set Google Maps api key, even if Google Maps is not loaded

= 1.0.65 =
Fix conditional logic for exclude field (again)


= 1.0.64 =
Fix conditional logic for exclude field

= 1.0.63 =
Bugfix

= 1.0.62 =
Option to exclude admins and editors from Google Analytics tracking

= 1.0.61 =
Line breaks etc

= 1.0.60 =
Add info about wp_body_open

= 1.0.59 =
Refactored external scripts loading, better option page with tabs + Added support for custom snippets

= 1.0.58 =
Stop Yoast from displaying update notifications to editors

= 1.0.57 =
Bugfix + rename User Caps class

= 1.0.56 =
Added filter to override login logo with code

= 1.0.55 =
Option to let one editor manage users + option to give editors full gravity forms access

= 1.0.54 =
Option to override {admin_email} value on setting-page

= 1.0.53 =
Set included ACF field group to private

= 1.0.52 =
Allow input of Google Maps key without having to also enqueue google maps frontend

= 1.0.51 =
Fix for when svg is missing from disk

= 1.0.50 =
Add another fallback for getting svg proportions correctly

= 1.0.49 =
Dequeue Gutenberg styles only if plugin timestamp is before the Biden inauguration

= 1.0.48 =
Option to add Facebook pixel

= 1.0.47 =
Fix getting login logo contents when using self-signed SSL

= 1.0.46 =
ACF exists check + admin notice

= 1.0.45 =
Now checks if get_field exists as a function to avoid breakage if ACF is disabled or being updated

= 1.0.44 =
Updated plugin update checker class to version 4.9

= 1.0.43 =
* Added option for removing the "Extra CSS"-section from the theme-customizer

= 1.0.42 =
* Tweaked the comment check from previous version

= 1.0.41 =
* Added a check to see if comments is enabled in Appex Publish

= 1.0.40 =
* Added option for setting callback-function for Google Maps
* Added option for adding `common-js` as dependency of Google Maps

= 1.0.39 =
Updated Plugin Updater Class to latest version

= 1.0.38 =
Update test

= 1.0.37 =
More reliable calculation of login logo ratio + use new filter

= 1.0.36 =
Enqueue Google Maps API in head

= 1.0.35 =
* Moved acf load json function out of init

= 1.0.34 =
* Plugin is now loaded on init to prevent conflicts when ACF is missing

= 1.0.33 =
* Typekit fonts are now loaded via CSS

= 1.0.32 =
* Fixed user login function

= 1.0.31 =
* Added a check to see if ACF active. If not, try to activate it

= 1.0.30 =
* Removed Gutenberg block css from front

= 1.0.29 =
* Added checkbox toggle to activate comments

= 1.0.27 =
* Check if Google Maps is already enqueued

= 1.0.26 =
* Check that ACF is activated before using get_field.

= 1.0.22 =
* Load default set of security headers if not set yet.

= 1.0.21 =
* Option to disable/enable defeault security headers. Also added support for LocalJson

= 1.0.20 =
*Added acf-filter to set Google Maps key

= 1.0.19 =
* Added security headers.

= 1.0.18 =
* Hide ACF admin menu if current user != admin. Hiding it for everybody in production makes the plugin impossible to update.

= 1.0.17 =
* Added Google Tag Manager option

= 1.0.16 =
* Bugfix

= 1.0.15 =
* New Google Analytics snippet

= 1.0.14 =
* Hide ACF admin menu item if domain != dev.* / *.local
