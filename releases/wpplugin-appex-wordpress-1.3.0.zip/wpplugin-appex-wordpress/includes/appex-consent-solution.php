<?php
$appex_consent_banner_heading = get_field('appex_consent_banner_heading', 'option');
$appex_consent_banner_text = get_field('appex_consent_banner_text', 'option');
$appex_consent_banner_accept_button_text = get_field('appex_consent_banner_accept_button_text', 'option') ?: 'OK';
$appex_consent_banner_has_decline_button = get_field('appex_consent_banner_has_decline_button', 'option');
$appex_consent_banner_decline_button_text = get_field('appex_consent_banner_decline_button_text', 'option') ?: 'Nei takk';
$appex_consent_banner_privacy_link = get_field('appex_consent_banner_privacy_link', 'option');
$appex_consent_banner_privacy_link_title = get_field('appex_consent_banner_privacy_link_title', 'option');
$appex_consent_banner_has_consent_change_button = get_field('appex_consent_banner_has_consent_change_button', 'option');

// Colors
$appex_consent_banner_background_color = get_field('appex_consent_banner_background_color', 'option') ?: '#fff';
$appex_consent_banner_text_color = get_field('appex_consent_banner_text_color', 'option') ?: '#000';
$appex_consent_banner_accept_button_background_color = get_field('appex_consent_banner_accept_button_background_color', 'option');
$appex_consent_banner_accept_button_text_color = get_field('appex_consent_banner_accept_button_text_color', 'option');
$appex_consent_banner_accept_button_hover_color = get_field('appex_consent_banner_accept_button_hover_color', 'option');
$appex_consent_banner_consent_change_button_color = get_field('appex_consent_banner_consent_change_button_color', 'option') ?: '#ffffff';
$appex_consent_banner_consent_change_button_icon_color = get_field('appex_consent_banner_consent_change_button_icon_color', 'option') ?: '#000000';
?>

<style>
    .appex-consent-banner {
        background-color: <?php echo $appex_consent_banner_background_color; ?> !important;
    }

    .appex-consent-banner h3,
    .appex-consent-banner p,
    .appex-consent-banner a,
    .appex-consent-banner .appex-consent-banner__buttons .button-decline {
        color: <?php echo $appex_consent_banner_text_color; ?> !important;
    }

    .appex-consent-banner .appex-consent-banner__buttons .button-accept {
        <?php
        if ($appex_consent_banner_accept_button_background_color != '') {
            echo 'background-color: ' . $appex_consent_banner_accept_button_background_color . ' !important;';
            echo 'border: 2px solid ' . $appex_consent_banner_accept_button_background_color . ' !important;';
        }

        if ($appex_consent_banner_accept_button_text_color != '') {
            echo 'color: ' . $appex_consent_banner_accept_button_text_color . ' !important;';
        }
        ?>
    }

    .appex-consent-banner .appex-consent-banner__buttons .button-decline {
        background-color: transparent !important;

        <?php
        if ($appex_consent_banner_accept_button_background_color != '') {
            echo 'border: 2px solid ' . $appex_consent_banner_accept_button_background_color . ' !important;';
        }
        ?>
    }

    <?php
    if ($appex_consent_banner_accept_button_hover_color != '') {
        echo '.appex-consent-banner .appex-consent-banner__buttons .button-accept:hover {';
        echo 'background-color: ' . $appex_consent_banner_accept_button_hover_color . ' !important;';
        echo 'border-color: ' . $appex_consent_banner_accept_button_hover_color . ' !important;';
        echo '}';
    }
    ?>
</style>

<div class="appex-consent-banner appex-consent-banner__bottom" id="appexConsentBanner">
    <div class="appex-consent-banner__body">
        <div class="appex-consent-banner__details">
            <?php
                if($appex_consent_banner_heading && $appex_consent_banner_heading != '') { 
                    echo '<h3>' . $appex_consent_banner_heading . '</h3>';
                }
                if ($appex_consent_banner_text && $appex_consent_banner_text != '') {
                    echo '<p>' . $appex_consent_banner_text . '</p>';
                }
             ?>
        </div>
        <div class="appex-consent-banner__buttons">
            <?php if($appex_consent_banner_has_decline_button) { ?>
                <button class="button-decline"><?php echo $appex_consent_banner_decline_button_text; ?></button>
            <?php } ?>
            <button class="button-accept"><?php echo $appex_consent_banner_accept_button_text; ?> </button>
        </div>
    </div>
    <div class="appex-consent-banner__footer">
        <?php
            if ($appex_consent_banner_privacy_link && $appex_consent_banner_privacy_link !== '' && $appex_consent_banner_privacy_link_title && $appex_consent_banner_privacy_link_title !== '') {
                echo '<p><a href="' . $appex_consent_banner_privacy_link . '">' . $appex_consent_banner_privacy_link_title . '</a></p>';
            }
        ?>
    </div>
    <div class="appex-consent-banner__close appex-consent-banner__button-close">
        <svg class="close-icon" xmlns="http://www.w3.org/2000/svg" width=24 height=24 viewBox="0 0 24 24">
            <path d="M18.364 5.636a.5.5 0 0 1 0 .707L12.707 12l5.657 5.657a.5.5 0 0 1-.707.707L12 12.707 6.343 18.364a.5.5 0 0 1-.707-.707L11.293 12 5.636 6.343a.5.5 0 0 1 .707-.707L12 11.293l5.657-5.657a.5.5 0 0 1 .707 0z"/>
        </svg>
    </div>
</div>
<?php if($appex_consent_banner_has_consent_change_button) { ?>
    <button type="button" class="appex-consent-reopen" id="appexConsentReopen" aria-label="<?php echo esc_attr__('Open consent banner', 'appex-wordpress'); ?>" title="<?php echo esc_attr__('Endre samtykke', 'appex-wordpress'); ?>" aria-hidden="true" tabindex="-1" style="background-color: <?php echo $appex_consent_banner_consent_change_button_color; ?>;">
        <span class="appex-consent-reopen__icon" style="--icon-url: url('<?php echo esc_url(plugin_dir_url(dirname(__FILE__, 2) . '/appex-wordpress.php') . 'assets/images/icons/privacy.svg'); ?>'); --icon-color: <?php echo $appex_consent_banner_consent_change_button_icon_color; ?>;"></span>
    </button>
<?php } ?>