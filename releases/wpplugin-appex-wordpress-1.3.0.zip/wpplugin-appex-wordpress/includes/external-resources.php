<?php

class AppexWordPressExternalScripts
{

    var $head_snippets = array();
    var $body_top_snippets = array();
    var $body_bottom_snippets = array();
    var $appex_wordpress_cookie_information_activated = false;

    function __construct()
    {
        $this->add_activated_scripts();
        $this->add_hooks();
    }

    public function add_activated_scripts()
    {
        $this->appex_wordpress_cookie_information_activated = get_field('appex_wordpress_cookie_information_activated', 'option');

        if ($this->appex_wordpress_cookie_information_activated) {
            $this->add_cookie_information_script();
        }

        if (get_field('appex_wordpress_google_analytics_activated', 'option') && $appex_wordpress_google_analytics_id = get_field('appex_wordpress_google_analytics_id', 'option')) {
            $this->add_google_analytics_script($appex_wordpress_google_analytics_id, $this->appex_wordpress_cookie_information_activated);
        }

        if (get_field('appex_wordpress_google_tag_manager_activated', 'option') && $appex_wordpress_google_tag_manager_id = get_field('appex_wordpress_google_tag_manager_id', 'option')) {
            $this->add_google_tag_manager_script($appex_wordpress_google_tag_manager_id, $this->appex_wordpress_cookie_information_activated);
        }

        if (get_field('appex_wordpress_facebook_pixel_activated', 'option') && $appex_wordpress_facebook_pixel_id = get_field('appex_wordpress_facebook_pixel_id', 'option')) {
            $this->add_facebook_pixel_script($appex_wordpress_facebook_pixel_id, $this->appex_wordpress_cookie_information_activated);
        }

        if (get_field('appex_wordpress_typekit_activated', 'option') && $appex_wordpress_typekit_id = get_field('appex_wordpress_typekit_id', 'option')) {
            $this->enqueue_typekit($appex_wordpress_typekit_id);
        }

        if (get_field('appex_wordpress_stats_embed_activated', 'option') && $appex_wordpress_stats_embed = get_field('appex_wordpress_stats_embed', 'option')) {
          $this->add_stats_embed($appex_wordpress_stats_embed);
        }


        $appex_wordpress_google_maps_key = get_field('appex_wordpress_google_maps_key', 'option');
        if (get_field('appex_wordpress_google_maps_activated', 'option') && $appex_wordpress_google_maps_key) {
            $this->enqueue_google_maps($appex_wordpress_google_maps_key);
        }
        if($appex_wordpress_google_maps_key = get_field('appex_wordpress_google_maps_key', 'option')){
            $this->add_acf_filter_for_google_maps($appex_wordpress_google_maps_key);
        }
        if ($custom_snippets = get_field('appex_wordpress_custom_snippets', 'option')) {
            if (!empty($custom_snippets)) {
                $this->add_custom_snippets($custom_snippets);
            }
        }
    }


    public function add_hooks()
    {

        $abort = apply_filters('appex_wordpress_external_scripts_abort', false);
        if ($abort) {
            return;
        }

        $head_snippets = $this->head_snippets;
        add_action('wp_head', function () use ($head_snippets) {
            echo implode("\n", $head_snippets);
        });

        $body_top_snippets = $this->body_top_snippets;
        add_action('wp_body_open', function () use ($body_top_snippets) {
            echo implode("\n", $body_top_snippets);
        });

        $body_bottom_snippets = $this->body_bottom_snippets;
        add_action('wp_footer', function () use ($body_bottom_snippets) {
            echo implode("\n", $body_bottom_snippets);
        });
    }

    public function add_stats_embed($stats_url)
    {
      add_action('admin_menu', function () use ($stats_url) {
        add_menu_page('Statistikk', 'Statistikk', 'delete_private_posts', 'statistikk-dashboard', function () use ($stats_url) {
          echo '<style>body { overflow-y: hidden; }</style>';
          echo '<div>';
          echo '<iframe src="'. $stats_url .'" frameborder="0" style="border:0;height:100vh;width:100%" allowfullscreen></iframe>';
          echo '</div>';
        }, 'dashicons-chart-area', 2);
      });
    }

    public function add_cookie_information_script()
    {
        $cookie_information_lang_string = get_field('appex_wordpress_cookie_information_lang_string', 'option') ?: "NB";
        $cookie_information_accept_frequency = get_field('appex_wordpress_cookie_information_accept_frequency', 'option') ?: 365;
        $cookie_information_decline_frequency = get_field('appex_wordpress_cookie_information_decline_frequency', 'option') ?: 14;
        
        $markup = "
            <script type='text/javascript'>
                window.cookieInformationCustomConfig = { 
                    acceptFrequency:" . $cookie_information_accept_frequency . ", 
                    declineFrequency: " . $cookie_information_decline_frequency . "
                };
            </script>
            <script id='CookieConsent' src='https://policy.app.cookieinformation.com/uc.js' data-culture='" . $cookie_information_lang_string . "' data-gcm-version='2.0' type='text/javascript'></script>
        
        ";
        $this->head_snippets[] = $markup;
    }


    public function add_google_analytics_script($appex_wordpress_google_analytics_id, $use_cookie_information = false)
    {
        // Should be placed inside <head>

        $exclude_roles = get_field('appex_wordpress_google_analytics_exclude_roles', 'option');
        $current_user = wp_get_current_user();
        $current_user_role = ($current_user && $current_user->roles && !empty($current_user->roles)) ? $current_user->roles[0] : 'guest';

        if($exclude_roles && in_array($current_user_role, $exclude_roles)) {
            $markup = "";
        }
        else{
            $markup = "";
                if ($use_cookie_information) {
                $markup .= "<script async src='' data-consent-src='https://www.googletagmanager.com/gtag/js?id=" . $appex_wordpress_google_analytics_id . "' data-category-consent='cookie_cat_statistic'></script> ";
            } else {
                $markup .= "<script async src='https://www.googletagmanager.com/gtag/js?id=" . $appex_wordpress_google_analytics_id . "'></script>";
            }
            $markup .= "
            <script>
                window.dataLayer = window.dataLayer || [];
                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());
                gtag('config', '" . $appex_wordpress_google_analytics_id . "', {
                    'anonymize_ip': true,";
                $markup .= apply_filters('appex_wordpress_google_analytics_extra_tracking_settings', "\n");
           $markup .= "
                });
            </script>
            ";
        }


        $this->head_snippets[] = $markup;
    }


    public function add_google_tag_manager_script($google_tag_manager_id, $use_cookie_information)
    {

        // Script part should be placed inside <head>
        $use_cookie_information_category = $use_cookie_information ? "cookie_cat_statistic" : null;
        $markup = $this->inline_script_start($use_cookie_information_category);

        $markup .= "
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','" . $google_tag_manager_id . "');
        ";

        $markup .= $this->inline_script_end($use_cookie_information);

        $this->head_snippets[] = $markup;
    }


    public function add_facebook_pixel_script($facebook_pixel_id, $use_cookie_information)
    {
        // Should be added to the <head> section : https://www.facebook.com/business/help/952192354843755?id=1205376682832142

        $use_cookie_information_category = $use_cookie_information ? "cookie_cat_marketing" : null;
        $markup = $this->inline_script_start($use_cookie_information_category);
        $markup .= "
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '" . $facebook_pixel_id . "');
        fbq('track', 'PageView');
        ";
        $markup .= $this->inline_script_end($use_cookie_information);

        $this->head_snippets[] = $markup;
    }


    public function enqueue_typekit($typekit_id)
    {
        wp_enqueue_style('typekit', '//use.typekit.net/' . $typekit_id . '.css', array(), null);
    }

    public function enqueue_google_maps($appex_wordpress_google_maps_key)
    {

        add_action('wp_enqueue_scripts', function () use ($appex_wordpress_google_maps_key) {
            if (!wp_script_is('maps-js')) {

                $appex_wordpress_google_maps_callback = get_field('appex_wordpress_google_maps_callback', 'option');
                $map_callback_function = $appex_wordpress_google_maps_callback ? '&callback=' . $appex_wordpress_google_maps_callback : '';

                $appex_wordpress_google_maps_common_wait = get_field('appex_wordpress_google_maps_common_wait', 'option');
                $map_dep_array = $appex_wordpress_google_maps_common_wait ? array('common-js') : array();

                wp_register_script('maps-js', '//maps.googleapis.com/maps/api/js?key=' . $appex_wordpress_google_maps_key . $map_callback_function, $map_dep_array, true);
                wp_enqueue_script('maps-js');
            }
        });

    }

    public function add_acf_filter_for_google_maps($appex_wordpress_google_maps_key){
        add_filter('acf/fields/google_map/api', function ($api) use ($appex_wordpress_google_maps_key) {
            $api['key'] = $appex_wordpress_google_maps_key;
            return $api;
        });
    }

    public function add_custom_snippets($custom_snippets)
    {
        foreach ($custom_snippets as $snippet) {
            switch ($snippet['placement']) {
                case 'head':
                    !empty($snippet['code']) ? $this->head_snippets[] = $snippet['code'] : null;
                    break;
                case 'body_top':
                    !empty($snippet['code']) ? $this->body_top_snippets[] = $snippet['code'] : null;
                    break;
                case 'body_bottom':
                    !empty($snippet['code']) ? $this->body_bottom_snippets[] = $snippet['code'] : null;
                    break;
            }
        }
    }

    public function inline_script_start($use_cookie_information_category = null)
    {

        $markup = "\n<script>";
        if ($use_cookie_information_category != null) {
            $markup .= "
            window.addEventListener('CookieInformationConsentGiven', function (event) {
                if (CookieInformation.getConsentGivenFor('" . $use_cookie_information_category . "')) {
            ";
        }

        return $markup;
    }

    public function inline_script_end($use_cookie_information = false)
    {
        $markup = "";
        if ($use_cookie_information) {
            $markup .= "
                    }
                }, false);
            ";
        }
        $markup .= "\n</script>\n";

        return $markup;
    }
}

new AppexWordPressExternalScripts;
