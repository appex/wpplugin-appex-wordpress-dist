<?php
/**
 * Plugin actions for the WebCare dashboard: POST /wp-json/appex/v1/plugins
 *
 * The same file ships in the Appex WordPress plugin (includes/command-endpoint.php) and in Appex
 * Webcare Status (wp-plugin/appex-webcare-status/ in the webcare-dashboard repo); keep the two
 * identical. Appex Webcare Status only loads its copy when the Appex plugin hasn't loaded one.
 *
 * The dashboard can enable, disable or remove the plugin groups listed in APPEX_COMMANDS_GROUPS and
 * nothing else, so the dashboard's key can't touch any other plugin. Installing (part of enable,
 * where the plugin is missing) only downloads from the dashboard itself (APPEX_COMMANDS_PACKAGE_BASE),
 * and only a zip whose SHA-256 the signed request names.
 *
 * Requests are signed with Ed25519, by a different key than status reads; only public keys live
 * here. The signed message is
 *   "appex-command-v1\n<timestamp>\n<nonce>\n<host>\n<route>\n<SHA-256 of the body, hex>"
 * Signatures are accepted for 5 minutes and each nonce only once, so a request can't be replayed,
 * sent to another site or changed on the way.
 *
 * Body: {"action": "enable" | "disable" | "remove", "group": "wp-migrate",
 *        "package": {"url": "...", "sha256": "..."}}   (package: for enable, used if missing)
 * Answer: {"plugins": [{"slug", "name", "version", "active"}]}, the group's plugins afterwards.
 */

if (!defined('ABSPATH')) {
	exit;
}

// Base64-encoded Ed25519 public keys allowed to run actions. Add a new key here before rotating
// the dashboard's NUXT_APPEX_COMMAND_PRIVATE_KEY, then remove the old one.
const APPEX_COMMANDS_PUBLIC_KEYS = [
	'HEiQoitt8zMey3RezVzxjtJy5tqsJBEEu3eNZ9YVuqI=',
];

// Plugin groups the dashboard may act on. `prefix` matches the plugin folders that disable and
// remove apply to (the plugin, its add-ons and older editions); enable activates `main`,
// installing it first if it's missing. `mu` lists must-use files the plugin leaves behind, deleted
// on remove.
const APPEX_COMMANDS_GROUPS = [
	// WP Migrate (Pro), formerly WP Migrate DB Pro, and its add-ons.
	'wp-migrate' => [
		'prefix' => 'wp-migrate-db',
		'main' => 'wp-migrate-db-pro/wp-migrate-db-pro.php',
		'mu' => ['wp-migrate-db-pro-compatibility.php'],
	],
];

// Installs only download from here.
const APPEX_COMMANDS_PACKAGE_BASE = 'https://webcare.appex.dev/packages/';

const APPEX_COMMANDS_MAX_CLOCK_SKEW = 300;
const APPEX_COMMANDS_ROUTE = '/appex/v1/plugins';

add_action('rest_api_init', function () {
	register_rest_route('appex/v1', '/plugins', [
		'methods' => 'POST',
		'callback' => 'appex_commands_handle',
		'permission_callback' => 'appex_commands_permission',
	]);
});

// The nonce is only used up here, once the request is about to run; the check in
// rest_authentication_errors below doesn't use it up.
function appex_commands_permission(WP_REST_Request $request)
{
	$nonce = (string) $request->get_header('x_appex_nonce');
	$verified = appex_commands_verify(
		$request->get_header('x_appex_timestamp'),
		$nonce,
		$request->get_header('x_appex_signature'),
		$request->get_route(),
		$request->get_body()
	);
	if ($verified !== true) {
		return $verified;
	}

	$key = 'appex_cmd_' . md5($nonce);
	if (get_site_transient($key)) {
		return new WP_Error('appex_command_replayed', 'This request has already been used.', ['status' => 401]);
	}
	set_site_transient($key, 1, 2 * APPEX_COMMANDS_MAX_CLOCK_SKEW + 60);

	return true;
}

// Some sites run security plugins that block the REST API for logged-out visitors through this
// filter. Let correctly signed action requests through; everything else is untouched.
add_filter('rest_authentication_errors', function ($result) {
	if (!is_wp_error($result)) {
		return $result;
	}

	$route = untrailingslashit($GLOBALS['wp']->query_vars['rest_route'] ?? '');
	if ($route !== APPEX_COMMANDS_ROUTE) {
		return $result;
	}

	$verified = appex_commands_verify(
		$_SERVER['HTTP_X_APPEX_TIMESTAMP'] ?? null,
		$_SERVER['HTTP_X_APPEX_NONCE'] ?? null,
		$_SERVER['HTTP_X_APPEX_SIGNATURE'] ?? null,
		$route,
		file_get_contents('php://input')
	);

	return $verified === true ? true : $result;
}, PHP_INT_MAX);

/**
 * @return true|WP_Error
 */
function appex_commands_verify($timestamp, $nonce, $signature_b64, $route, $body)
{
	$signature = base64_decode((string) $signature_b64, true);

	if (!ctype_digit((string) $timestamp) || abs(time() - (int) $timestamp) > APPEX_COMMANDS_MAX_CLOCK_SKEW) {
		return new WP_Error('appex_command_expired', 'Missing or expired timestamp.', ['status' => 401]);
	}
	if (!preg_match('/^[A-Za-z0-9_-]{16,64}$/', (string) $nonce)) {
		return new WP_Error('appex_command_unsigned', 'Missing or malformed nonce.', ['status' => 401]);
	}
	if ($signature === false || strlen($signature) !== 64) {
		return new WP_Error('appex_command_unsigned', 'Missing or malformed signature.', ['status' => 401]);
	}

	// PHP's sodium extension is optional; WordPress bundles a polyfill.
	if (!function_exists('sodium_crypto_sign_verify_detached')) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}

	// The host the request was sent to, so a request signed for one site is refused by another.
	$host = strtolower(preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
	$message = implode("\n", ['appex-command-v1', $timestamp, $nonce, $host, $route, hash('sha256', (string) $body)]);
	foreach (APPEX_COMMANDS_PUBLIC_KEYS as $key) {
		if (sodium_crypto_sign_verify_detached($signature, $message, base64_decode($key))) {
			return true;
		}
	}

	return new WP_Error('appex_command_forbidden', 'Invalid signature.', ['status' => 401]);
}

// The group's installed plugins, by main file.
function appex_commands_files(array $group)
{
	$files = [];
	foreach (array_keys(get_plugins()) as $file) {
		$dir = dirname($file);
		if ($dir !== '.' && strpos($dir, $group['prefix']) === 0) {
			$files[] = $file;
		}
	}
	return $files;
}

function appex_commands_report(array $group)
{
	wp_clean_plugins_cache(false);
	$plugins = get_plugins();
	$report = [];
	foreach (appex_commands_files($group) as $file) {
		$report[] = [
			'slug' => dirname($file),
			'name' => $plugins[$file]['Name'],
			'version' => $plugins[$file]['Version'],
			'active' => is_plugin_active($file),
		];
	}
	return $report;
}

/**
 * Installs the group's main plugin from the dashboard.
 *
 * @return true|WP_Error
 */
function appex_commands_install(array $group, $package)
{
	$url = is_array($package) ? (string) ($package['url'] ?? '') : '';
	$sha256 = is_array($package) ? strtolower((string) ($package['sha256'] ?? '')) : '';
	if (strpos($url, APPEX_COMMANDS_PACKAGE_BASE) !== 0 || !preg_match('/^[a-f0-9]{64}$/', $sha256)) {
		return new WP_Error('appex_command_no_package', 'The plugin is not installed and no package was given.', ['status' => 400]);
	}

	$file = download_url($url, 60);
	if (is_wp_error($file)) {
		return $file;
	}
	if (!hash_equals($sha256, hash_file('sha256', $file))) {
		@unlink($file);
		return new WP_Error('appex_command_checksum', 'The downloaded package does not match its checksum.', ['status' => 502]);
	}

	$upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
	$result = $upgrader->install($file);
	@unlink($file);
	if (is_wp_error($result)) {
		return $result;
	}
	if (!$result) {
		$messages = $upgrader->skin->get_upgrade_messages();
		return new WP_Error('appex_command_install_failed', $messages ? wp_strip_all_tags(html_entity_decode(implode(' ', $messages))) : 'Installing the plugin failed.', ['status' => 500]);
	}
	if ($upgrader->plugin_info() !== $group['main']) {
		// Delete whatever it installed (a new folder: installing never overwrites one), without
		// running any of its code.
		global $wp_filesystem;
		if (!empty($upgrader->result['destination']) && $wp_filesystem) {
			$wp_filesystem->delete($upgrader->result['destination'], true);
		}
		return new WP_Error('appex_command_wrong_package', 'The package contained ' . ($upgrader->plugin_info() ?: 'no plugin') . ', not ' . $group['main'] . '.', ['status' => 500]);
	}

	return true;
}

function appex_commands_handle(WP_REST_Request $request)
{
	$params = $request->get_json_params() ?: [];
	$action = $params['action'] ?? '';
	$group = APPEX_COMMANDS_GROUPS[$params['group'] ?? ''] ?? null;
	if (!$group || !in_array($action, ['enable', 'disable', 'remove'], true)) {
		return new WP_Error('appex_command_invalid', 'Unknown action or plugin group.', ['status' => 400]);
	}

	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

	if ($action === 'enable') {
		if (!array_key_exists($group['main'], get_plugins())) {
			$installed = appex_commands_install($group, $params['package'] ?? null);
			if (is_wp_error($installed)) {
				return $installed;
			}
		}
		// Network-wide on multisites, which is how WP Migrate runs there. Runs its activation hook.
		$activated = activate_plugin($group['main'], '', is_multisite());
		if (is_wp_error($activated)) {
			return $activated;
		}
	} else {
		$files = appex_commands_files($group);
		// null: deactivates network-wide where it's network-active, and on this site where it's
		// active here.
		deactivate_plugins($files, false, null);

		if ($action === 'remove') {
			if ($files) {
				// Runs each plugin's uninstall routine, then deletes its folder.
				$deleted = delete_plugins($files);
				if (is_wp_error($deleted)) {
					return $deleted;
				}
				if ($deleted !== true) {
					return new WP_Error('appex_command_delete_failed', 'WordPress could not delete the plugin files.', ['status' => 500]);
				}
			}
			foreach ($group['mu'] as $mu) {
				if (is_file(WPMU_PLUGIN_DIR . '/' . $mu)) {
					@unlink(WPMU_PLUGIN_DIR . '/' . $mu);
				}
			}
		}
	}

	$response = rest_ensure_response(['plugins' => appex_commands_report($group)]);
	$response->header('Cache-Control', 'no-store, private');
	return $response;
}
