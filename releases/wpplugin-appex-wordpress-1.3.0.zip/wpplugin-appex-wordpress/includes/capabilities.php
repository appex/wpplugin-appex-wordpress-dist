<?php
class Appex_Wordpress_User_Caps
{
	public function __construct()
	{
		add_action('init', array($this, 'add_user_manager_role'));
		add_action('init', array($this, 'set_user_manager_for_selected_user'));
		add_action('init', array($this, 'add_gravity_forms_access_for_editors'));

		add_filter('editable_roles', array($this, 'editable_roles'));
		add_filter('map_meta_cap', array($this, 'map_meta_cap'), 10, 4);
		add_action('pre_user_query',  array($this, 'pre_user_query'));
		add_filter("views_users", array($this, 'modify_list_user_view'));
	}


	public	function add_user_manager_role()
	{

		if (get_option('appex_add_user_role_once') != 'done_v1') {

			$role_object = add_role(
				'user_manager',
				'Brukeradministrator'
			);

			if (!$role_object){
				$role_object = get_role('user_manager');
			}

			$role_object->add_cap('edit_users');
			$role_object->add_cap('list_users');
			$role_object->add_cap('promote_users');
			$role_object->add_cap('create_users');
			$role_object->add_cap('add_users');
			$role_object->add_cap('delete_users');
			$role_object->add_cap('delete_others_pages');
			$role_object->add_cap('delete_pages');

			update_option('appex_add_user_role_once', 'done_v1');
		}
	}



	// Let editor role manage users
	public function set_user_manager_for_selected_user()
	{
		$appex_user_administrator_id = get_field('appex_user_administrator_id', 'option');
		if (get_option('appex_add_user_management_capability_once') != $appex_user_administrator_id) {
			// Remove existing roles
			$user_args = array(
				'role' => 'user_manager',
			);
			$user_query = new WP_User_Query($user_args);
			if (!empty($user_query->get_results())) {
				foreach ($user_query->get_results() as $user) {
					$user->remove_role('user_manager');
				}
			}

			// Add role to new admin
			$user = new WP_User($appex_user_administrator_id);
			$user->add_role('user_manager');
			update_option('appex_add_user_management_capability_once', $appex_user_administrator_id);
		}
	}

	public function add_gravity_forms_access_for_editors()
	{
		$appex_wordpress_editor_gf_access = get_field('appex_wordpress_editor_gf_access', 'option', false);


		if ($appex_wordpress_editor_gf_access == "1" && get_option('appex_add_gform_capabilities_to_editor_once') != 'editor_done_v1') {
			$role_object = get_role('editor');

			/* View entries */
			$role_object->add_cap('gravityforms_export_entries');
			$role_object->add_cap('gravityforms_view_entries');
			$role_object->add_cap('gravityforms_view_entry_notes');

			/* Edit form, entries and settings */
			$role_object->add_cap('gravityforms_create_form');
			$role_object->add_cap('gravityforms_delete_entries');
			$role_object->add_cap('gravityforms_delete_forms');
			$role_object->add_cap('gravityforms_edit_entries');
			$role_object->add_cap('gravityforms_edit_entry_notes');
			$role_object->add_cap('gravityforms_edit_forms');
			$role_object->add_cap('gravityforms_edit_settings');
			$role_object->add_cap('gravityforms_feed');
			$role_object->add_cap('gravityforms_view_settings');

			update_option('appex_add_gform_capabilities_to_editor_once', 'editor_done_v1');
		}
		elseif ($appex_wordpress_editor_gf_access == "0" && get_option('appex_add_gform_capabilities_to_editor_once') == 'editor_done_v1') {
			$role_object = get_role('editor');

			/* View entries */
			$role_object->remove_cap('gravityforms_export_entries');
			$role_object->remove_cap('gravityforms_view_entries');
			$role_object->remove_cap('gravityforms_view_entry_notes');

			/* Edit form, entries and settings */
			$role_object->remove_cap('gravityforms_create_form');
			$role_object->remove_cap('gravityforms_delete_entries');
			$role_object->remove_cap('gravityforms_delete_forms');
			$role_object->remove_cap('gravityforms_edit_entries');
			$role_object->remove_cap('gravityforms_edit_entry_notes');
			$role_object->remove_cap('gravityforms_edit_forms');
			$role_object->remove_cap('gravityforms_edit_settings');
			$role_object->remove_cap('gravityforms_feed');
			$role_object->remove_cap('gravityforms_view_settings');

			update_option('appex_add_gform_capabilities_to_editor_once', 'editor_removed_v1');

		}
	}


	// Remove 'Administrator' from the list of roles if the current user is not an admin
	public function editable_roles($roles)
	{
		if (isset($roles['administrator']) && !current_user_can('administrator')) {
			unset($roles['administrator']);
		}
		return $roles;
	}

	// If someone is trying to edit or delete and admin and that user isn't an admin, don't allow it
	public function map_meta_cap($caps, $cap, $user_id, $args)
	{

		switch ($cap) {
			case 'edit_user':
			case 'remove_user':
			case 'promote_user':
				if (isset($args[0]) && $args[0] == $user_id) {
					break;
				} elseif (!isset($args[0])) {
					$caps[] = 'do_not_allow';
				}

				$other = new WP_User(absint($args[0]));
				if ($other->has_cap('administrator')) {
					if (!current_user_can('administrator')) {
						$caps[] = 'do_not_allow';
					}
				}
				break;
			case 'delete_user':
			case 'delete_users':
				if (!isset($args[0])) {
					break;
				}

				$other = new WP_User(absint($args[0]));
				if ($other->has_cap('administrator')) {
					if (!current_user_can('administrator')) {
						$caps[] = 'do_not_allow';
					}
				}
				break;
			default:
				break;
		}
		return $caps;
	}

	// hide admin from user list
	public function pre_user_query($user_search)
	{
		$user = wp_get_current_user();
		if ($user_search->query_vars['meta_key'] == 'appex_login_user_phone_number' || $user_search->query_vars['meta_key'] == 'user_mobile_phone' || !is_admin()) {
			return $user_search;
		}

		if ($user->ID != 1) { // Is not administrator, remove administrator
			global $wpdb;
			$user_search->query_where = str_replace(
				'WHERE 1=1',
				"WHERE 1=1 AND {$wpdb->users}.ID<>1",
				$user_search->query_where
			);
		}
		return $user_search;
	}


	public function modify_list_user_view($views)
	{
		if (!current_user_can('administrator')) {
			$users = count_users();
			$admins_num = $users['avail_roles']['administrator'] - 1;
			$all_num = $users['total_users'] - 1;
			$user_manager_num = $users['avail_roles']['user_manager'] - 1;
			$class_adm = (strpos($views['administrator'], 'current') === false) ? "" : "current";
			$class_all = (strpos($views['all'], 'current') === false) ? "" : "current";
			$class_user_manager = (strpos($views['user_manager'], 'current') === false) ? "" : "current";
			$views['administrator'] = '<a href="users.php?role=administrator" class="' . $class_adm . '">' . translate_user_role('Administrator') . ' <span class="count">(' . $admins_num . ')</span></a>';
			$views['all'] = '<a href="users.php" class="' . $class_all . '">' . __('All') . ' <span class="count">(' . $all_num . ')</span></a>';
			$views['user_manager'] = '<a href="users.php?role=user_manager" class="' . $class_user_manager . '">' . __('Brukeradministrator') . ' <span class="count">(' . $user_manager_num . ')</span></a>';
			unset($views['administrator']);
		}
		return $views;
	}
}

$Appex_Wordpress_User_Caps = new Appex_Wordpress_User_Caps();
