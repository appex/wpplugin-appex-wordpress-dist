<?php
/**
 * Read-only status endpoint for the WebCare dashboard: GET /wp-json/appex/v1/status
 *
 * Reports WordPress, PHP, theme and plugin versions, available updates, auto-update settings,
 * search engine visibility and WP Migrate's push and pull settings, using the data WordPress
 * already keeps. Loaded before the ACF
 * check in appex-wordpress.php so it keeps reporting on sites where ACF is broken.
 *
 * Requests must be signed by the dashboard with Ed25519. Only public keys live here, so
 * nothing secret ships with the plugin. The signed message is "<timestamp>\n<route>" and
 * signatures are accepted for 5 minutes.
 */

if (!defined('ABSPATH')) {
	exit;
}

// Base64-encoded Ed25519 public keys allowed to read the status. Add a new key here before
// rotating the dashboard's private key, then remove the old one.
const APPEX_STATUS_PUBLIC_KEYS = [
	'YDugbg2hJitRFSvT2soFFcOok/KJ07si+u/JIL6uK8E=',
];

const APPEX_STATUS_MAX_CLOCK_SKEW = 300;

add_action('rest_api_init', function () {
	register_rest_route('appex/v1', '/status', [
		'methods' => 'GET',
		'callback' => 'appex_status_response',
		'permission_callback' => 'appex_status_verify_request',
	]);
});

function appex_status_verify_request(WP_REST_Request $request)
{
	return appex_status_verify(
		$request->get_header('x_appex_timestamp'),
		$request->get_header('x_appex_signature'),
		$request->get_route()
	);
}

// Some sites run security plugins that block the REST API for logged-out visitors through
// this filter. Let correctly signed status requests through; everything else is untouched.
add_filter('rest_authentication_errors', function ($result) {
	if (!is_wp_error($result)) {
		return $result;
	}

	$route = untrailingslashit($GLOBALS['wp']->query_vars['rest_route'] ?? '');
	if ($route !== '/appex/v1/status') {
		return $result;
	}

	$verified = appex_status_verify(
		$_SERVER['HTTP_X_APPEX_TIMESTAMP'] ?? null,
		$_SERVER['HTTP_X_APPEX_SIGNATURE'] ?? null,
		$route
	);

	return $verified === true ? true : $result;
}, PHP_INT_MAX);

/**
 * @return true|WP_Error
 */
function appex_status_verify($timestamp, $signature_b64, $route)
{
	$signature = base64_decode((string) $signature_b64, true);

	if (!ctype_digit((string) $timestamp) || abs(time() - (int) $timestamp) > APPEX_STATUS_MAX_CLOCK_SKEW) {
		return new WP_Error('appex_status_expired', 'Missing or expired timestamp.', ['status' => 401]);
	}
	if ($signature === false || strlen($signature) !== 64) {
		return new WP_Error('appex_status_unsigned', 'Missing or malformed signature.', ['status' => 401]);
	}

	// PHP's sodium extension is optional; WordPress bundles a polyfill.
	if (!function_exists('sodium_crypto_sign_verify_detached')) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}

	$message = $timestamp . "\n" . $route;
	foreach (APPEX_STATUS_PUBLIC_KEYS as $key) {
		if (sodium_crypto_sign_verify_detached($signature, $message, base64_decode($key))) {
			return true;
		}
	}

	return new WP_Error('appex_status_forbidden', 'Invalid signature.', ['status' => 401]);
}

// Whether WordPress's automatic updater runs at all (AUTOMATIC_UPDATER_DISABLED, DISALLOW_FILE_MODS,
// the automatic_updater_disabled filter). When it doesn't, nothing updates automatically.
function appex_status_updater_disabled()
{
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-automatic-updater.php';
	return (new WP_Automatic_Updater())->is_disabled();
}

// Core auto-updates, resolved the way Core_Upgrader::should_update_to_version() does:
// stored settings, then the WP_AUTO_UPDATE_CORE constant, then filters.
// Returns 'major' (all releases), 'minor' (security/maintenance only) or 'disabled'.
function appex_status_core_auto_update($updater_disabled)
{
	if ($updater_disabled) {
		return 'disabled';
	}

	$minor = get_site_option('auto_update_core_minor', 'enabled') === 'enabled';
	$major = get_site_option('auto_update_core_major', 'unset') === 'enabled';

	if (defined('WP_AUTO_UPDATE_CORE')) {
		if (WP_AUTO_UPDATE_CORE === false) {
			$minor = $major = false;
		} elseif (WP_AUTO_UPDATE_CORE === true || in_array(WP_AUTO_UPDATE_CORE, ['beta', 'rc', 'development', 'branch-development'], true)) {
			$minor = $major = true;
		} elseif (WP_AUTO_UPDATE_CORE === 'minor') {
			$minor = true;
			$major = false;
		}
	}

	$minor = apply_filters('allow_minor_auto_core_updates', $minor);
	$major = apply_filters('allow_major_auto_core_updates', $major);

	return $major ? 'major' : ($minor ? 'minor' : 'disabled');
}

// Another site can push its database to this one, or pull this one's, only when these are on and
// it has the connection key. The settings outlive the plugin, so they're read even when it's off.
function appex_status_wp_migrate()
{
	$settings = get_site_option('wpmdb_settings');
	if (!is_array($settings)) {
		return null;
	}
	return [
		'allowPush' => !empty($settings['allow_push']),
		'allowPull' => !empty($settings['allow_pull']),
	];
}

function appex_status_response()
{
	global $wp_version;

	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/update.php';

	$updater_disabled = appex_status_updater_disabled();
	$plugin_auto_updates_supported = function_exists('wp_is_auto_update_enabled_for_type') && wp_is_auto_update_enabled_for_type('plugin');
	$plugin_auto_updates = (array) get_site_option('auto_update_plugins', []);

	$plugin_updates = get_site_transient('update_plugins');
	$plugins = [];
	foreach (get_plugins() as $file => $data) {
		$slug = dirname($file) === '.' ? basename($file, '.php') : dirname($file);

		// A host or plugin can force auto-updates on or off with the auto_update_plugin filter;
		// otherwise it's the per-plugin toggle on the Plugins screen. Same check WordPress uses there.
		$item = (object) array_merge(['plugin' => $file, 'slug' => $slug, 'new_version' => $data['Version']], (array) ($plugin_updates->response[$file] ?? []));
		$forced = function_exists('wp_is_auto_update_forced_for_item') ? wp_is_auto_update_forced_for_item('plugin', null, $item) : null;
		$enabled = $forced !== null ? (bool) $forced : ($plugin_auto_updates_supported && in_array($file, $plugin_auto_updates, true));

		$plugins[] = [
			'slug' => $slug,
			'name' => $data['Name'],
			'version' => $data['Version'],
			'active' => is_plugin_active($file),
			'update' => $plugin_updates->response[$file]->new_version ?? null,
			// Whether this plugin will update itself, and whether that's forced by code rather than the toggle.
			'autoUpdate' => !$updater_disabled && $enabled,
			'autoUpdateForced' => $forced !== null,
		];
	}

	$core_update = null;
	foreach (get_site_transient('update_core')->updates ?? [] as $offer) {
		if (($offer->response ?? '') === 'upgrade') {
			$core_update = $offer->current;
			break;
		}
	}

	$theme = wp_get_theme();
	$theme_updates = get_site_transient('update_themes');

	$response = rest_ensure_response([
		'appexVersion' => get_file_data(dirname(__DIR__) . '/appex-wordpress.php', ['Version' => 'Version'])['Version'],
		'wordpress' => [
			'version' => $wp_version,
			'update' => $core_update,
			'autoUpdate' => appex_status_core_auto_update($updater_disabled),
		],
		'php' => PHP_VERSION,
		'theme' => [
			'name' => $theme->get('Name'),
			'version' => $theme->get('Version'),
			'update' => $theme_updates->response[$theme->get_stylesheet()]['new_version'] ?? null,
		],
		'plugins' => $plugins,
		// True when WordPress's automatic updater is switched off entirely.
		'autoUpdatesDisabled' => $updater_disabled,
		// False when "Discourage search engines from indexing this site" (Settings > Reading) is on.
		'searchEngineVisible' => (string) get_option('blog_public') !== '0',
		// WP Migrate's "Allow push" and "Allow pull" settings, or null if it has never saved any.
		'wpMigrate' => appex_status_wp_migrate(),
		// Plugin groups the dashboard can enable, disable and remove (command-endpoint.php).
		'commands' => defined('APPEX_COMMANDS_GROUPS') ? array_keys(APPEX_COMMANDS_GROUPS) : [],
		// When WordPress last checked for plugin updates; null if it never has.
		'checkedAt' => isset($plugin_updates->last_checked) ? gmdate('c', $plugin_updates->last_checked) : null,
	]);
	$response->header('Cache-Control', 'no-store, private');

	return $response;
}
