<?php
/**
 * Keeps this plugin up to date on every site: WordPress auto-updates it (through the update
 * checker in appex-wordpress.php) whatever the per-plugin toggle on the Plugins screen says.
 * Releases are tested before they're published (merging to master publishes), so new versions
 * reach all sites within about a day without anyone updating them by hand.
 *
 * To pause automatic rollout, remove this file's require in appex-wordpress.php and release.
 */

if (!defined('ABSPATH')) {
	exit;
}

function appex_self_auto_update_basename()
{
	return plugin_basename(dirname(__DIR__) . '/appex-wordpress.php');
}

add_filter('auto_update_plugin', function ($update, $item) {
	return isset($item->plugin) && $item->plugin === appex_self_auto_update_basename() ? true : $update;
}, 10, 2);

// WordPress emails the site admin (often the client) after automatic updates. Skip that email
// when this plugin is the only thing that was updated, and it worked.
add_filter('auto_plugin_update_send_email', function ($enabled, $results) {
	if (!$enabled || empty($results)) {
		return $enabled;
	}
	foreach ($results as $result) {
		if (empty($result->result) || ($result->item->plugin ?? '') !== appex_self_auto_update_basename()) {
			return $enabled;
		}
	}
	return false;
}, 10, 2);
