// On document load
document.addEventListener('DOMContentLoaded', () => {
    const appexConsentBanner = document.getElementById('appexConsentBanner');

    function gtag() {
        dataLayer.push(arguments);
    }
    // Check if GTM is installed
    function isGTMInstalled() {
        if (window.dataLayer && Array.isArray(window.dataLayer)) {
            return true;
        }
        return false;
    }

    if (appexConsentBanner && isGTMInstalled()) {
        // eslint-disable-next-line no-undef
        const config = appexConsentBannerConfig || {};

        const declineFrequency = config.declineFrequency || 15;

        const acceptButton = appexConsentBanner.querySelector('.button-accept');
        const declineButton = appexConsentBanner.querySelector('.button-decline');
        const buttonClose = appexConsentBanner.querySelector('.appex-consent-banner__button-close');

        const displayConsentBanner = () => {
            appexConsentBanner.style.display = 'block';
            setTimeout(() => {
                appexConsentBanner.classList.add('active');
            }, 400);
        };

        let hideConsentBanner = () => {
            appexConsentBanner.classList.remove('active');

            setTimeout(() => {
                appexConsentBanner.style.display = 'none';
            }, 400);
        };

        const updateLocalStorage = (consentGiven) => {
            const consentDate = Date.now();

            const consentObject = {
                consentGiven,
                consentDate,
            };

            localStorage.setItem('appexTrackingConsent', JSON.stringify(consentObject));
        };

        const sendConsentEvent = (type, status) => {
            gtag('consent', type, {
                ad_storage: status,
                ad_user_data: status,
                ad_personalization: status,
                analytics_storage: status,
            });
        };

        const acceptTracking = () => {
            updateLocalStorage('true');
            sendConsentEvent('update', 'granted');
        };

        const declineTracking = () => {
            updateLocalStorage('false');
            sendConsentEvent('update', 'denied');
        };

        const checkTrackingConsent = () => {
            if (!localStorage.getItem('appexTrackingConsent')) {
                sendConsentEvent('update', 'denied');
                displayConsentBanner();
            } else {
                const consentObject = JSON.parse(localStorage.getItem('appexTrackingConsent'));
                if (consentObject.consentGiven === 'false') {
                    const currentTimestamp = Date.now();
                    const expirationTime = consentObject.consentDate + declineFrequency * 24 * 60 * 60 * 1000;

                    sendConsentEvent('update', 'denied');

                    if (currentTimestamp >= expirationTime) {
                        // Consent has expired
                        displayConsentBanner();
                    }
                } else {
                    hideConsentBanner();
                    sendConsentEvent('update', 'granted');
                }
            }
        };

        // Click events
        acceptButton.addEventListener('click', () => {
            acceptTracking();
            hideConsentBanner();
        });

        if (declineButton) {
            declineButton.addEventListener('click', () => {
                declineTracking();
                hideConsentBanner();
            });
        }

        buttonClose.addEventListener('click', () => {
            hideConsentBanner();
        });

        // Check consent on page load
        checkTrackingConsent();

        // Reopen button: show when banner is closed, hide when banner is open
        const reopenButton = document.getElementById('appexConsentReopen');
        if (reopenButton) {
            reopenButton.addEventListener('click', () => {
                displayConsentBanner();
                reopenButton.classList.remove('visible');
                reopenButton.setAttribute('aria-hidden', 'true');
                reopenButton.setAttribute('tabindex', '-1');
            });

            const showReopenButton = () => {
                reopenButton.classList.add('visible');
                reopenButton.setAttribute('aria-hidden', 'false');
                reopenButton.setAttribute('tabindex', '0');
            };

            const originalHideConsentBanner = hideConsentBanner;
            hideConsentBanner = () => {
                originalHideConsentBanner();
                setTimeout(showReopenButton, 450);
            };
            // When user had already consented, banner is hidden on load → show reopen after hide animation
            if (appexConsentBanner.style.display !== 'block') {
                setTimeout(showReopenButton, 100);
            }
        }
    }
});
