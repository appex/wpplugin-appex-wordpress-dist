<?php
/*
 * Plugin Name: Appex WordPress
 * Version: 1.2.1
 * Plugin URI: https://appex.no
 * Description: Standard tweaks and additions for Appex WordPress websites
 * Author: Appex
 * Author URI: http://appex.no
 */

// Status endpoint for the WebCare dashboard. Loaded before the ACF check so it keeps
// reporting on sites where ACF is missing.
require_once(__DIR__ . '/includes/status-endpoint.php');

// Updates, also loaded before the ACF check so sites without ACF still get new versions.
// They're read from a public distribution repo, so sites need no GitHub credentials.
// .github/workflows/release.yml publishes info.json and the plugin zip there on every version bump.
require 'plugin-update-checker/plugin-update-checker.php';

$pluginUpdateChecker = Puc_v4_Factory::buildUpdateChecker(
	'https://raw.githubusercontent.com/appex/wpplugin-appex-wordpress-dist/main/info.json',
	__FILE__,
	'wpplugin-appex-wordpress'
);

// This plugin always updates itself automatically.
require_once(__DIR__ . '/includes/self-auto-update.php');

// This plugin needs ACF to function, so return if ACF is not activated
if (!class_exists('ACF')) {

	$path = plugin_basename(__FILE__);

	add_action('after_plugin_row_' . $path, function () {
?>

		<tr class="plugin-update-tr active">
			<td colspan="3" class="plugin-update colspanchange">
				<div class="update-message notice inline notice-error notice-alt">
					<p>
						This plugin can't load because Advanced Custom Fields needs to be installed and activated.
					</p>
				</div>
			</td>
		</tr>

	<?php
	}, 5);


	add_action('admin_head', function () {
		$path = plugin_basename(__FILE__);

	?>

		<style>
			.plugins tr[data-plugin='<?php echo $path; ?>'] th,
			.plugins tr[data-plugin='<?php echo $path; ?>'] td {
				box-shadow: none;
			}
		</style>

<?php
	});

	// Abort everything else
	return;
}

// Includes
require_once(__DIR__ . '/includes/capabilities.php');

function appex_init_plugin()
{
	// Try to activate ACF if isn't – to prevent the whole site breaking down
	if (!class_exists('ACF')) {
		$active_plugins = get_option('active_plugins');

		array_push($active_plugins, 'advanced-custom-fields-pro/acf.php'); /* Here just replace unyson plugin directory and plugin file*/
		update_option('active_plugins', $active_plugins);
	}

	appex_plugin_functionality();
}
add_action('init', 'appex_init_plugin');


// Enable support for LocalJson plugin
add_filter('aljm_save_json',  'appex_wordpress_enable_save_local_json', 1);
function appex_wordpress_enable_save_local_json($folders)
{
	$folders['Appex WordPress'] = dirname(__DIR__) . '/appex-wordpress/acf-json';
	return $folders;
}

/*========================================
=            Security headers            =
========================================*/

add_action('send_headers', function () {

	if (function_exists('get_field')) {
		$secure_headers_defaults = array(
			'X-Frame-Options' => 'SAMEORIGIN',
			'X-Content-Type-Options' => 'nosniff',
			'X-XSS-Protection' => '1; mode=block',
			'Strict-Transport-Security' => 'max-age=31536000; includeSubDomains',
			'Referrer-Policy' => 'same-origin',
			'Content-Security-Policy' => 'frame-ancestors \'self\'',
		);

		$appex_wordpress_security_headers = get_field('appex_wordpress_security_headers', 'option') ? get_field('appex_wordpress_security_headers', 'option') : $secure_headers_defaults;

		foreach ($secure_headers_defaults as $secure_header_key => $secure_header) {
			if (in_array($secure_header_key, $appex_wordpress_security_headers)) {
				header($secure_header_key . ':' . $secure_header);
			}
		}
	}
});



/*=========================================================
=            Add external dependencies to page            =
=========================================================*/


// Add plugin acf-json folder to load_json
add_filter('acf/settings/load_json', function ($paths) {

	$paths[] = plugin_dir_path(__FILE__) . 'acf-json';

	return $paths;
});

function appex_plugin_functionality()
{

	// Store a timestamp for when the first plugin init hook is fired
	if (!get_option('appex_wordpress_first_activation_timestamp')) {
		update_option('appex_wordpress_first_activation_timestamp', time());
	}


	if (function_exists('acf_add_options_page')) {
		acf_add_options_page(array(
			'page_title'		=> 'Globale innstillinger',
			'menu_title'		=> 'Nettside-innstillinger',
			'menu_slug'			=> 'appex-wordpress-site-options',
			'capability'	    => 'delete_private_posts', // Editor / Redaktør
			'parent_slug'		=> '',
			'position'			=> false,
			'icon_url'			=> 'dashicons-feedback',
			'redirect'			=> false,
			'show_in_graphql'   => true
		));
	}


	require_once(__DIR__ . '/includes/external-resources.php');
}


/*=====  End of Add external dependencies to page  ======*/



/*=========================================
=            Admin area tweaks            =
=========================================*/

function appex_wordpress_fix_user_caps()
{
	// Editor
	$role_object = get_role('editor');

	// Enable menu access
	$role_object->add_cap('edit_theme_options');

	// Gravity Forms access
	/* View entries */
	$role_object->add_cap('gravityforms_export_entries');
	$role_object->add_cap('gravityforms_view_entries');
	$role_object->add_cap('gravityforms_view_entry_notes');
}
register_activation_hook(__FILE__, 'appex_wordpress_fix_user_caps');

// Admin menu
if (function_exists('acf_add_options_page')) {

	add_action('admin_menu', function () {

		// Removes defined menu entries from admin panel
		global $menu;

		$appex_wordpress_remove_admin_menu_entries = get_field('appex_wordpress_remove_admin_menu_entries', 'option') ? get_field('appex_wordpress_remove_admin_menu_entries', 'option') : array();

		foreach ($appex_wordpress_remove_admin_menu_entries as $key => $entry) {
			$appex_wordpress_remove_admin_menu_entries[$key] = __($entry);
		}

		end($menu);
		while (prev($menu)) {
			$value = explode(' ', $menu[key($menu)][0]);
			if (in_array($value[0] != NULL ? $value[0] : "", $appex_wordpress_remove_admin_menu_entries)) {
				unset($menu[key($menu)]);
			}
		}

		// Hide ACF menu item if current user != admin
		$admins = array('appexdev');
		$current_user = wp_get_current_user();

		if (!in_array($current_user->user_login, $admins)) {
			remove_menu_page('edit.php?post_type=acf-field-group');
		}
	});
}



// Removes meta boxes from posts/pages
add_action('admin_init', function () {
	// remove_meta_box('categorydiv','post','normal'); // remove categories module
	// remove_meta_box('tagsdiv-post_tag','post','normal'); // remove tags module
	// remove_meta_box('postexcerpt','post','normal'); // remove excerpt module
	remove_meta_box('trackbacksdiv', 'post', 'normal'); // remove trackbacks module
	remove_meta_box('postcustom', 'post', 'normal'); // remove custom fields module

	if (!get_field('appex_wordpress_comments_activated', 'option')) {
		remove_meta_box('commentstatusdiv', 'post', 'normal'); // remove discussions module
		remove_meta_box('commentsdiv', 'post', 'normal'); // remove comments module
	}

	remove_meta_box('authordiv', 'post', 'normal'); // remove author module
	// remove_meta_box('revisionsdiv','post','normal'); // remove revisions module

	remove_meta_box('postcustom', 'page', 'normal'); // remove custom fields module
	remove_meta_box('trackbacksdiv', 'page', 'normal'); // remove trackbacks module
	remove_meta_box('commentstatusdiv', 'page', 'normal'); // remove discussion module
	remove_meta_box('commentsdiv', 'page', 'normal'); // remove comments module
	remove_meta_box('authordiv', 'page', 'normal'); // remove author module

	add_post_type_support('page', [
		'excerpt',
	]);
});



// Disable dashboard widgets
add_action('admin_menu', function () {
	// remove_meta_box('dashboard_right_now', 'dashboard', 'core');
	if (!get_field('appex_wordpress_comments_activated', 'option')) {
		remove_meta_box('dashboard_recent_comments', 'dashboard', 'core');
	}
	remove_meta_box('dashboard_incoming_links', 'dashboard', 'core');
	remove_meta_box('dashboard_plugins', 'dashboard', 'core');
	remove_meta_box('dashboard_quick_press', 'dashboard', 'core');
	remove_meta_box('dashboard_recent_drafts', 'dashboard', 'core');
	remove_meta_box('dashboard_primary', 'dashboard', 'core');
	remove_meta_box('dashboard_secondary', 'dashboard', 'core');
});

// Remove Gutenberg block editor css from front
add_action('wp_print_styles', 'wps_deregister_styles', 100);
function wps_deregister_styles()
{
	if (get_option('appex_wordpress_first_activation_timestamp') < 1611160200 || defined('appex_wordpress_force_dequeue_gutenberg_styles')) {
		wp_dequeue_style('wp-block-library');
	}
}


// Adds Appex link to admin footer
add_filter('admin_footer_text', function () {
	echo '<a href="https://appex.no" target="_blank">Appex made this!</a>';
});



// Log / count user logins
add_action('wp_login', function ($user_login, $user) {
	$current_time = current_time('timestamp');

	add_user_meta($user->ID, 'login_log', $current_time);
}, 10, 2);


// Add user login columns
add_filter('manage_users_columns', function ($columns) {
	return array_merge($columns, array(
		'login_log' => 'Siste login',
		'login_count' => 'Antall innlogginger'
	));
});

add_filter('manage_users_custom_column', function ($value, $column_name, $user_id) {
	if ($column_name == 'login_log') {
		$login_log = array_reverse(get_user_meta($user_id, 'login_log', false));

		if (!count($login_log) > 0) return '&mdash;';

		return date_i18n(get_option('date_format'), $login_log[0]) . ' kl. ' . date_i18n(get_option('time_format'), $login_log[0]);
	} elseif ($column_name == 'login_count') {
		$login_log = get_user_meta($user_id, 'login_log', false);
		return count($login_log);
	}
}, 10, 3);



// Enable SVG upload in Media Uploader
function appex_wordpress_mime_types($mimes)
{
	$mimes['svg'] = 'image/svg+xml';
	return $mimes;
}
add_filter('upload_mimes', 'appex_wordpress_mime_types');



// Hack to enabled display of SVG files in media browser
// Creds: https://css-tricks.com/snippets/wordpress/allow-svg-through-wordpress-media-uploader/#comment-1617191
function appex_wordpress_svg_meta_data($data, $id)
{

	$attachment = get_post($id); // Filter makes sure that the post is an attachment
	$mime_type = $attachment->post_mime_type; // The attachment mime_type

	//If the attachment is an svg

	if ($mime_type == 'image/svg+xml') {

		//If the svg metadata are empty or the width is empty or the height is empty
		//then get the attributes from xml.

		if (empty($data) || empty($data['width']) || empty($data['height'])) {

			$xml = simplexml_load_file(wp_get_attachment_url($id));
			$attr = $xml->attributes();
			$viewbox = explode(' ', $attr->viewBox);
			$data['width'] = isset($attr->width) && preg_match('/\d+/', $attr->width, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[2] : null);
			$data['height'] = isset($attr->height) && preg_match('/\d+/', $attr->height, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[3] : null);
		}
	}

	return $data;
}
add_filter('wp_update_attachment_metadata', 'appex_wordpress_svg_meta_data', 10, 2);


/*=====  End of Admin area tweaks  ======*/




/*========================================================
=            Appex WordPress helper functions            =
========================================================*/

// Check if is login page
function appex_wordpress_is_login_page()
{
	if (!isset($GLOBALS['pagenow'])) {
		return false;
	}
	return in_array($GLOBALS['pagenow'], array('wp-login.php', 'wp-register.php'));
}


function appex_wordpress_is_valid_login_logo($logo_array)
{
	if (!is_array($logo_array)) return false;
	if (!isset($logo_array['url'])) return false;
	if (!isset($logo_array['width'])) return false;
	if (!isset($logo_array['height'])) return false;
	return true;
}


if (appex_wordpress_is_login_page()) {

	$appex_wordpress_login_page_logo_activated = get_option('options_appex_wordpress_login_page_logo_activated', false);
	if ($appex_wordpress_login_page_logo_activated) {

		# Changing the login page URL
		add_filter(
			'login_headerurl',
			function () {
				return get_bloginfo('url');
			}
		);

		# Changing the login page URL hover text
		add_filter(
			'login_headertext',
			function () {
				return get_bloginfo('name');
			}
		);

		# Login screen
		add_action(
			'login_head',
			function () {

				$logo = wp_get_attachment_image_src(get_field('appex_wordpress_login_page_logo', 'option'), 'full');
				$logo_array =  array(
					'url' => isset($logo[0]) ? $logo[0] : null,
					'width' => isset($logo[1]) ? $logo[1] : null,
					'height' => isset($logo[2]) ? $logo[2] : null
				);


				if ($logo_array['url'] && !appex_wordpress_is_valid_login_logo($logo_array)) {

					$arrContextOptions = array(
						'ssl' => array(
							"verify_peer" => false,
							"verify_peer_name" => false,
							"allow_self_signed" => true,
						)
					);
					$logo_file_contents = file_get_contents($logo_array['url'], false, stream_context_create($arrContextOptions));
					$svgfile = simplexml_load_string($logo_file_contents);
					if ($svgfile) {
						$attr = $svgfile->attributes();
						$logo_array['width'] = substr($attr['width'], 0, -2);
						$logo_array['height'] = substr($attr['height'], 0, -2);

						if (!$logo_array['width'] || !$logo_array['height']) {

							$viewbox = explode(' ', $attr->viewBox);
							$logo_array['width'] = isset($attr->width) && preg_match('/\d+/', $attr->width, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[2] : null);
							$logo_array['height'] = isset($attr->height) && preg_match('/\d+/', $attr->height, $value) ? (int) $value[0] : (count($viewbox) == 4 ? (int) $viewbox[3] : null);
						}
					}
				}


				$logo_array = apply_filters('appex_wordpress_login_page_logo', $logo_array);


				if (appex_wordpress_is_valid_login_logo($logo_array)) {


					$ratio = $logo_array['height'] / $logo_array['width'];
					$percent = round((float)$ratio * 100) . '%';

					echo '<style type="text/css">
					#login h1 a {
						background: url(' . $logo_array['url'] . ') center center no-repeat;
						background-size: 100%;
						height: 0;
						padding-bottom: ' . $percent . ';
						width: 100%;
					}

				</style>';
				}
			}
		);
	}
}




// Pretty dumping of variables
if (!function_exists('aw_dump')) {

	function aw_dump($dump)
	{
		echo '<pre style="text-align: left;">' . print_r($dump, true) . '</pre>';
	}
}

/*=====  End of Appex WordPress helper functions  ======*/


/*====================================
=            Theme tweaks            =
====================================*/

// Enable post thumbnails
add_theme_support('post-thumbnails');

// Enable title tag
add_theme_support('title-tag');

// Remove version info from head and feeds
add_filter('the_generator', function () {
	return '';
});


// Remove junk from the <head>
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'feed_links', 2);
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'feed_links_extra', 3);
remove_action('wp_head', 'start_post_rel_link', 10, 0);
remove_action('wp_head', 'parent_post_rel_link', 10, 0);
remove_action('wp_head', 'adjacent_posts_rel_link', 10, 0);


/*=====  End of Theme tweaks  ======*/



/*=====  Preserve options on WP Migrate DB migrations  ======*/
function appex_wordpress_wpmdb_preserved_options($options, $intent = '')
{
	$options[] = 'acf_pro_license';   // Advanced Custom Fields Pro License
	$options[] = 'cpupdate_cac-pro';  // Admin Columns Pro License
	return $options;
}
add_filter('wpmdb_preserved_options', 'appex_wordpress_wpmdb_preserved_options', 99, 2);

// Log to file using error_log function
// Requires the following contants in wp-config.php to work correctly

/*
	define('WP_DEBUG', true);
	define('SAVEQUERIES', true );
	define('WP_DEBUG_LOG', true);
	define('WP_DEBUG_DISPLAY', true );
*/

if (!function_exists('_log')) {
	function _log($message)
	{
		if (WP_DEBUG === true) {
			if (is_array($message) || is_object($message)) {
				error_log(print_r($message, true));
			} else {
				error_log($message);
			}
		}
	}
}

function appex_wordpress_remove_custom_css_section($wp_customize)
{
	if (function_exists('get_field')) {
		$css_option = get_field('appex_wordpress_hide_customizer_css', 'option');
		if (!isset($css_option) || $css_option == true) {
			$wp_customize->remove_section('custom_css');
		}
	}
}
add_action('customize_register', 'appex_wordpress_remove_custom_css_section', 15);



function appex_wordpress_modify_gform_notification_email_recipient($notification)
{
	$custom_admin_email = get_field('appex_wordpress_gravity_forms_admin_email_value', 'option');
	if (isset($custom_admin_email) && !empty($custom_admin_email)) {
		// Replaces {admin_emails} in to fields
		if (array_key_exists('toEmail', $notification)) {
			$notification['toEmail'] = str_replace('{admin_email}', $custom_admin_email, $notification['toEmail']);
		}
		if (array_key_exists('to', $notification)) {
			$notification['to'] = str_replace('{admin_email}', $custom_admin_email, $notification['to']);
		}
		if (array_key_exists('from', $notification)) {
			$notification['from'] = str_replace('{admin_email}', $custom_admin_email, $notification['from']);
		}

		// Replaces {admin_emails} in from fields (but allows for overrides)
		if (!isset($notification['from']) || empty($notification['from'])) {
			$notification['from'] = $custom_admin_email;
		}
	}
	return $notification;
}
add_filter('gform_notification', 'appex_wordpress_modify_gform_notification_email_recipient');



function appex_wordpress_modify_gform_export_separator($separator)
{
  $custom_separator = get_field('appex_wordpress_gravity_forms_export_separator', 'option');
  if (isset($custom_separator) && !empty($custom_separator)) {
	$separator = $custom_separator;
  }
  return $separator;
}
add_filter('gform_export_separator', 'appex_wordpress_modify_gform_export_separator', 10, 1);


// Adds a column for usage, and then queries all pages and finds where the gravity forms are in use
add_filter('gform_form_list_columns', function ($columns) {

	$gf_show_usage_column = get_field('appex_wordpress_gf_usage_column', 'option');
	if ($gf_show_usage_column && !empty($gf_show_usage_column)) {
		$post_args = array(
			'post_type' => 'any',
			'post_status' => 'any',
			'posts_per_page' => -1,
		);
		$posts = get_posts($post_args);
		$gforms = array();
		foreach ($posts as $key => $post) {

			$is_gutenberg = use_block_editor_for_post($post->ID);

			if ($is_gutenberg) {
				$blocks = parse_blocks($post->post_content);
				foreach ($blocks as $block) {
					if ($block['blockName'] == 'gravityforms/form' && !in_array($block['attrs']['formId'], $gforms)) {
						$gforms[$block['attrs']['formId']][] = $post->ID;
					}
				}
			} else {

				$content = $post->post_content;
				$tag = 'gravityform';

				if (has_shortcode($content, $tag)) {
					preg_match_all('/' . get_shortcode_regex() . '/s', $content, $matches, PREG_SET_ORDER);

					if (!empty($matches)) {
						foreach ($matches as $shortcode) {
							$form_id = null;
							if ($tag === $shortcode[2]) {
								$atts = shortcode_parse_atts($shortcode[3]);

								if (isset($atts['id'])) {
									$form_id = $atts['id'];
								}
							}
						}
						if (isset($form_id)) {
							$gforms[$form_id][] = $post->ID;
						}
					}
				}
			}
		}
		update_option('gforms_overview_cache', $gforms);
		$columns['usage'] = 'Bruk';
	}
	return $columns;
});

add_action('gform_form_list_column_usage', function ($form) {

	$gf_show_usage_column = get_field('appex_wordpress_gf_usage_column', 'option');
	if ($gf_show_usage_column && !empty($gf_show_usage_column)) {

		$gforms_overview_cache = get_option('gforms_overview_cache');
		$form_id = (int) $form->id;
		$markup = '';
		if (isset($gforms_overview_cache[$form_id])) {
			$markup .= '<details>';
			$post_ids = $gforms_overview_cache[$form_id];
			$page_string = count($post_ids) == 1 ? ' side' : ' sider';
			$markup .= '<summary>I bruk på ' . count($post_ids) . $page_string . '</summary>';
			$posts = get_posts(array('post_type' => 'any', 'post_status' => 'any', 'post__in' => $post_ids));
			foreach ($posts as $post) {
				$markup .= '<div><a href="' . get_permalink($post->ID) . '">' . $post->post_title . '</a></div>';
			}
			$markup .= '</details>';
		}
		echo $markup;
	}
});


// Stop Yoast from displaying update notifications to editors
add_filter('wpseo_update_notice_content', '__return_null');

// Remove author tag
add_filter('wpseo_meta_author', function ($author_name) {
	if (get_field('appex_wordpress_remove_yoast_author_tag', 'option') === true) return false;
	return $author_name;
});

add_filter('two_factor_providers', function ($providers) {
	unset($providers['Two_Factor_FIDO_U2F']);
	unset($providers['Two_Factor_Backup_Codes']);
	unset($providers['Two_Factor_Dummy']);
	return $providers;
});

add_filter('two_factor_enabled_providers_for_user', function ($providers, $user_id) {
	$force_roles = [
		'administrator',
	];
	$appex_wordpress_two_factor_forced_for_roles = get_field('appex_wordpress_two_factor_forced_for_roles', 'option');

	if ($appex_wordpress_two_factor_forced_for_roles && !empty($appex_wordpress_two_factor_forced_for_roles)) {
		$force_roles = array_merge($force_roles, $appex_wordpress_two_factor_forced_for_roles);
	}
	$user = get_user_by('id', $user_id);
	if (empty(array_intersect($force_roles, $user->roles))) {
		return $providers;
	}
	if (empty($providers) && class_exists('Two_Factor_Email')) {
		$providers[] = 'Two_Factor_Email';
	}
	return $providers;
}, 10, 2);



/*========================================
=  Allow editors to edit privacy policy  =
========================================*/
function appex_wordpress_custom_manage_privacy_options($caps, $cap, $user_id, $args) {
	if (!is_user_logged_in()) return $caps;

	$user_meta = get_userdata($user_id);
	if (is_bool($user_meta) || !is_array($user_meta->roles)) return $caps;

	if (array_intersect(['editor', 'administrator'], $user_meta->roles)) {
		if ('manage_privacy_options' === $cap) {
			$manage_name = is_multisite() ? 'manage_network' : 'manage_options';
			$caps = array_diff($caps, [ $manage_name ]);
		}
	}

	return $caps;
}
add_action('map_meta_cap', 'appex_wordpress_custom_manage_privacy_options', 1, 4);


/*=========================================
=            Appex Samtykkeløsning        =
=========================================*/
add_action('acf/init', function () {
	if (is_admin()) return;
	if (get_field('appex_wordpress_cookie_information_activated', 'option')) return;

	if (get_field('appex_consent_banner_activated', 'option')) {
		// Set default values early
		add_action('wp_head', function () {
			echo "<script>
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}

				if (!localStorage.getItem('appexTrackingConsent')) {
					gtag('consent', 'default', {
						'ad_storage': 'denied',
						'ad_user_data': 'denied',
						'ad_personalization': 'denied',
						'analytics_storage': 'denied'
					});
				} else {
					const existingConsentObject = JSON.parse(localStorage.getItem('appexTrackingConsent'));
					if (existingConsentObject.consentGiven === 'false') {
						gtag('consent', 'default', {
							'ad_storage': 'denied',
							'ad_user_data': 'denied',
							'ad_personalization': 'denied',
							'analytics_storage': 'denied'
						});
						
					} else {
						gtag('consent', 'default', {
							'ad_storage': 'granted',
							'ad_user_data': 'granted',
							'ad_personalization': 'granted',
							'analytics_storage': 'granted'
						});
					}
				}
			
			</script>";
		});

		// Send consent update after Google Listings & Ads (wp_head priority 999999)
		add_action('wp_head', function () {
			echo "<script>
				window.dataLayer = window.dataLayer || [];
				function gtag(){dataLayer.push(arguments);}

				try {
					const storedConsent = localStorage.getItem('appexTrackingConsent');
					if (storedConsent) {
						const existingConsentObject = JSON.parse(storedConsent);
						const consentStatus = existingConsentObject.consentGiven === 'false' ? 'denied' : 'granted';

						gtag('consent', 'update', {
							'ad_storage': consentStatus,
							'ad_user_data': consentStatus,
							'ad_personalization': consentStatus,
							'analytics_storage': consentStatus
						});
					}
				} catch (e) {}
			</script>";
		}, 1000000);


		// Defaults
		$appex_consent_banner_decline_frequency = get_field('appex_consent_banner_decline_frequency', 'option') ?: 15;

		// Styles and scripts
		$versionConsentBannerStyles = filemtime(plugin_dir_path(__FILE__) . 'assets/css/appex-consent-banner.css');
		$versionConsentBannerScript = filemtime(plugin_dir_path(__FILE__) . 'assets/js/appex-consent-banner.js');

		wp_enqueue_style('appex_consent_banner_styles', plugin_dir_url(__FILE__) . 'assets/css/appex-consent-banner.css', [], $versionConsentBannerStyles);

		wp_register_script('appex_consent_banner_script', plugin_dir_url(__FILE__) . 'assets/js/appex-consent-banner.js', [], $versionConsentBannerScript, false);
		wp_localize_script('appex_consent_banner_script', 'appexConsentBannerConfig', [
			'declineFrequency' => $appex_consent_banner_decline_frequency,
		]);

		wp_enqueue_script('appex_consent_banner_script');

		add_action('wp_footer', function () {
			require_once(__DIR__ . '/includes/appex-consent-solution.php');
		});
	}
});



/*=========================================
=            Bulk comment management      =
=========================================*/

add_action('admin_init', function () {
	add_settings_section(
		'bulk_comments_section',
		'Masseredigering av kommentarer',
		'bulk_comments_section_callback',
		'discussion',
	);

	add_settings_field(
		'bulk_comments_actions',
		'Masseredigering for innlegg',
		'bulk_comments_field_callback',
		'discussion',
		'bulk_comments_section',
	);
});

function bulk_comments_section_callback() {
	echo '<p>Administrer kommentarer for alle innlegg på en gang.</p>';
}

function bulk_comments_field_callback() {
	global $wpdb;
	$total_posts = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'post'");
	$closed_comments = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'post' AND comment_status = 'closed'");
	$open_comments = $total_posts - $closed_comments;

	echo '<ul style="margin-top: 0; padding-top: 5px;">';
	echo '<li><strong>Totalt antall innlegg:</strong> ' . $total_posts . '</li>';
	echo '<li><strong>Innlegg med åpne kommentarer:</strong> ' . $open_comments . '</li>';
	echo '<li><strong>Innlegg med lukkede kommentarer:</strong> ' . $closed_comments . '</li>';
	echo '</ul>';

	echo '<button type="button" id="disable-all-comments" class="button button-primary"'; if ($open_comments == 0) { echo ' disabled'; } echo '>Deaktiver kommentarer på alle innlegg</button> ';
	echo '<button type="button" id="enable-all-comments" class="button button-secondary"'; if ($closed_comments == 0) { echo ' disabled'; } echo '>Aktiver kommentarer på alle innlegg</button>';
	?>
	<script type="text/javascript">
	jQuery(document).ready(function($) {
		$('#disable-all-comments').click(function() {
			if (confirm('Er du sikker på at du vil deaktivere kommentarer på alle innlegg?')) {
				bulkUpdateComments('disable');
			}
		});

		$('#enable-all-comments').click(function() {
			if (confirm('Er du sikker på at du vil aktivere kommentarer på alle innlegg?')) {
				bulkUpdateComments('enable');
			}
		});

		function bulkUpdateComments(action) {
			var button = $('#' + action + '-all-comments');
			var originalText = button.text();
			button.text('Behandler...').prop('disabled', true);

			$.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: 'bulk_update_comments',
					comment_action: action,
					nonce: '<?php echo wp_create_nonce('bulk_comments_nonce'); ?>'
				},
				success: function(response) {
					if (response.success) {
						alert('Suksess: ' + response.data.message);
						location.reload();
					} else {
						alert('Feil: ' + response.data.message);
					}
				},
				error: function() {
					alert('En feil oppstod. Vennligst prøv igjen.');
				},
				complete: function() {
					button.text(originalText).prop('disabled', false);
				}
			});
		}
	});
	</script>
	<?php
}

add_action('wp_ajax_bulk_update_comments', function () {
	if (!wp_verify_nonce($_POST['nonce'], 'bulk_comments_nonce')) {
		wp_die('Security check failed');
	}

	if (!current_user_can('manage_options')) {
		wp_send_json_error(['message' => 'Utilstrekkelige tillatelser']);
		return;
	}

	$action = sanitize_text_field($_POST['comment_action']);
	$comment_status = ($action === 'disable') ? 'closed' : 'open';

	global $wpdb;
	$updated_count = $wpdb->query(
		$wpdb->prepare(
			"UPDATE {$wpdb->posts} SET comment_status = %s WHERE post_type = 'post'",
			$comment_status
		)
	);

	$message = sprintf(
		'Kommentarer %s på %d innlegg.',
		($action === 'disable') ? 'deaktivert' : 'aktivert',
		$updated_count
	);

	wp_send_json_success(['message' => $message]);
});
