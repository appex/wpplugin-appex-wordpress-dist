<?php
/**
 * Plugin actions for the WebCare dashboard: POST /wp-json/appex/v1/plugins
 *
 * The same file ships in the Appex WordPress plugin (includes/command-endpoint.php) and in Appex
 * Webcare Status (wp-plugin/appex-webcare-status/ in the webcare-dashboard repo); keep the two
 * identical. Appex Webcare Status only loads its copy when the Appex plugin hasn't loaded one.
 *
 * The dashboard can enable, disable or remove the plugin groups listed in APPEX_COMMANDS_GROUPS and
 * nothing else, so the dashboard's key can't touch any other plugin. Installing (part of enable,
 * where the plugin is missing) only downloads from the dashboard itself (APPEX_COMMANDS_PACKAGE_BASE),
 * and only a zip whose SHA-256 the signed request names.
 *
 * Requests are signed with Ed25519, by a different key than status reads; only public keys live
 * here. The signed message is
 *   "appex-command-v1\n<timestamp>\n<nonce>\n<host>\n<route>\n<SHA-256 of the body, hex>"
 * Signatures are accepted for 5 minutes and each nonce only once, so a request can't be replayed,
 * sent to another site or changed on the way.
 *
 * Body: {"action": "enable" | "disable" | "remove", "group": "wp-migrate",
 *        "package": {"url": "...", "sha256": "..."}}   (package: for enable, used if missing)
 *    or {"action": "update", "group": "appex"}: update the Appex plugins themselves now, from their
 *        own update feeds (APPEX_COMMANDS_SELF), instead of waiting for WordPress's next check.
 * Answer: {"plugins": [{"slug", "name", "version", "active"}]}, the group's plugins afterwards
 *        (for update: as they are now, plus "scheduled": true; the update runs in WP-Cron).
 *
 * One action per group at a time (409 otherwise), and an action runs to the end even if the
 * dashboard stops waiting. Remove moves the plugin's folder (and its must-use files) out of the way
 * in one step, into wp-content/upgrade/appex-removed-*, so it's quick and never leaves a
 * half-deleted plugin. The files there are deleted by WP-Cron, started right after answering: WP
 * Engine doesn't let PHP delete .php files during ordinary web requests, but does in WP-Cron (as
 * WordPress's own background updates need). The folder is closed to web requests meanwhile. The
 * status reports how many such folders a site has (pluginLeftovers); where cron doesn't run,
 * scripts/clean-removed-plugins.sh in the webcare-dashboard repo deletes them over SSH.
 */

if (!defined('ABSPATH')) {
	exit;
}

// Base64-encoded Ed25519 public keys allowed to run actions. Add a new key here before rotating
// the dashboard's NUXT_APPEX_COMMAND_PRIVATE_KEY, then remove the old one.
const APPEX_COMMANDS_PUBLIC_KEYS = [
	'HEiQoitt8zMey3RezVzxjtJy5tqsJBEEu3eNZ9YVuqI=',
];

// Plugin groups the dashboard may act on. `prefix` matches the plugin folders that disable and
// remove apply to (the plugin, its add-ons and older editions); enable activates `main`,
// installing it first if it's missing. `mu` lists must-use files the plugin leaves behind, deleted
// on remove.
const APPEX_COMMANDS_GROUPS = [
	// WP Migrate (Pro), formerly WP Migrate DB Pro, and its add-ons.
	'wp-migrate' => [
		'prefix' => 'wp-migrate-db',
		'main' => 'wp-migrate-db-pro/wp-migrate-db-pro.php',
		'mu' => ['wp-migrate-db-pro-compatibility.php'],
	],
];

// Installs only download from here.
const APPEX_COMMANDS_PACKAGE_BASE = 'https://webcare.appex.dev/packages/';

// Reported in the status (commandsVersion). 2: one action at a time, remove in one step.
// 3: update (the Appex plugins themselves), removed files deleted by WP-Cron.
const APPEX_COMMANDS_VERSION = 3;

// What "update" may update: the Appex plugins, matched by main file name (their folders differ
// between sites), each from its own update feed. Only packages under the feed's own base are used.
const APPEX_COMMANDS_SELF = [
	'appex-wordpress.php' => [
		'feed' => 'https://raw.githubusercontent.com/appex/wpplugin-appex-wordpress-dist/main/info.json',
		'packages' => 'https://raw.githubusercontent.com/appex/wpplugin-appex-wordpress-dist/',
	],
	'appex-webcare-status.php' => [
		'feed' => 'https://webcare.appex.dev/updates/appex-webcare-status/info.json',
		'packages' => 'https://webcare.appex.dev/updates/appex-webcare-status/',
	],
];

const APPEX_COMMANDS_MAX_CLOCK_SKEW = 300;
// Removed plugin folders wait here until their files are deleted, after the answer is sent.
const APPEX_COMMANDS_TRASH_PREFIX = 'appex-removed-';
const APPEX_COMMANDS_ROUTE = '/appex/v1/plugins';

add_action('rest_api_init', function () {
	register_rest_route('appex/v1', '/plugins', [
		'methods' => 'POST',
		'callback' => 'appex_commands_handle',
		'permission_callback' => 'appex_commands_permission',
	]);
});

// The nonce is only used up here, once the request is about to run; the check in
// rest_authentication_errors below doesn't use it up.
function appex_commands_permission(WP_REST_Request $request)
{
	$nonce = (string) $request->get_header('x_appex_nonce');
	$verified = appex_commands_verify(
		$request->get_header('x_appex_timestamp'),
		$nonce,
		$request->get_header('x_appex_signature'),
		$request->get_route(),
		$request->get_body()
	);
	if ($verified !== true) {
		return $verified;
	}

	$key = 'appex_cmd_' . md5($nonce);
	if (get_site_transient($key)) {
		return new WP_Error('appex_command_replayed', 'This request has already been used.', ['status' => 401]);
	}
	set_site_transient($key, 1, 2 * APPEX_COMMANDS_MAX_CLOCK_SKEW + 60);

	return true;
}

// Some sites run security plugins that block the REST API for logged-out visitors through this
// filter. Let correctly signed action requests through; everything else is untouched.
add_filter('rest_authentication_errors', function ($result) {
	if (!is_wp_error($result)) {
		return $result;
	}

	$route = untrailingslashit($GLOBALS['wp']->query_vars['rest_route'] ?? '');
	if ($route !== APPEX_COMMANDS_ROUTE) {
		return $result;
	}

	$verified = appex_commands_verify(
		$_SERVER['HTTP_X_APPEX_TIMESTAMP'] ?? null,
		$_SERVER['HTTP_X_APPEX_NONCE'] ?? null,
		$_SERVER['HTTP_X_APPEX_SIGNATURE'] ?? null,
		$route,
		file_get_contents('php://input')
	);

	return $verified === true ? true : $result;
}, PHP_INT_MAX);

/**
 * @return true|WP_Error
 */
function appex_commands_verify($timestamp, $nonce, $signature_b64, $route, $body)
{
	$signature = base64_decode((string) $signature_b64, true);

	if (!ctype_digit((string) $timestamp) || abs(time() - (int) $timestamp) > APPEX_COMMANDS_MAX_CLOCK_SKEW) {
		return new WP_Error('appex_command_expired', 'Missing or expired timestamp.', ['status' => 401]);
	}
	if (!preg_match('/^[A-Za-z0-9_-]{16,64}$/', (string) $nonce)) {
		return new WP_Error('appex_command_unsigned', 'Missing or malformed nonce.', ['status' => 401]);
	}
	if ($signature === false || strlen($signature) !== 64) {
		return new WP_Error('appex_command_unsigned', 'Missing or malformed signature.', ['status' => 401]);
	}

	// PHP's sodium extension is optional; WordPress bundles a polyfill.
	if (!function_exists('sodium_crypto_sign_verify_detached')) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}

	// The host the request was sent to, so a request signed for one site is refused by another.
	$host = strtolower(preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? '')));
	$message = implode("\n", ['appex-command-v1', $timestamp, $nonce, $host, $route, hash('sha256', (string) $body)]);
	foreach (APPEX_COMMANDS_PUBLIC_KEYS as $key) {
		if (sodium_crypto_sign_verify_detached($signature, $message, base64_decode($key))) {
			return true;
		}
	}

	return new WP_Error('appex_command_forbidden', 'Invalid signature.', ['status' => 401]);
}

// The group's installed plugins, by main file.
function appex_commands_files(array $group)
{
	$files = [];
	foreach (array_keys(get_plugins()) as $file) {
		$dir = dirname($file);
		if ($dir !== '.' && strpos($dir, $group['prefix']) === 0) {
			$files[] = $file;
		}
	}
	return $files;
}

function appex_commands_report(array $group)
{
	wp_clean_plugins_cache(false);
	$plugins = get_plugins();
	$report = [];
	foreach (appex_commands_files($group) as $file) {
		$report[] = [
			'slug' => dirname($file),
			'name' => $plugins[$file]['Name'],
			'version' => $plugins[$file]['Version'],
			'active' => is_plugin_active($file),
		];
	}
	return $report;
}

/**
 * Installs the group's main plugin from the dashboard.
 *
 * @return true|WP_Error
 */
function appex_commands_install(array $group, $package)
{
	$url = is_array($package) ? (string) ($package['url'] ?? '') : '';
	$sha256 = is_array($package) ? strtolower((string) ($package['sha256'] ?? '')) : '';
	if (strpos($url, APPEX_COMMANDS_PACKAGE_BASE) !== 0 || !preg_match('/^[a-f0-9]{64}$/', $sha256)) {
		return new WP_Error('appex_command_no_package', 'The plugin is not installed and no package was given.', ['status' => 400]);
	}

	$file = download_url($url, 60);
	if (is_wp_error($file)) {
		return $file;
	}
	if (!hash_equals($sha256, hash_file('sha256', $file))) {
		@unlink($file);
		return new WP_Error('appex_command_checksum', 'The downloaded package does not match its checksum.', ['status' => 502]);
	}

	$upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
	$result = $upgrader->install($file);
	@unlink($file);
	if (is_wp_error($result)) {
		return $result;
	}
	if (!$result) {
		$messages = $upgrader->skin->get_upgrade_messages();
		return new WP_Error('appex_command_install_failed', $messages ? wp_strip_all_tags(html_entity_decode(implode(' ', $messages))) : 'Installing the plugin failed.', ['status' => 500]);
	}
	if ($upgrader->plugin_info() !== $group['main']) {
		// Delete whatever it installed (a new folder: installing never overwrites one), without
		// running any of its code.
		global $wp_filesystem;
		if (!empty($upgrader->result['destination']) && $wp_filesystem) {
			$wp_filesystem->delete($upgrader->result['destination'], true);
		}
		return new WP_Error('appex_command_wrong_package', 'The package contained ' . ($upgrader->plugin_info() ?: 'no plugin') . ', not ' . $group['main'] . '.', ['status' => 500]);
	}

	return true;
}

/**
 * Uninstalls the plugins and moves their folders to wp-content/upgrade/ in one rename each, so
 * WordPress sees them gone at once. The files are deleted after the answer (appex_commands_empty_trash).
 *
 * @return true|WP_Error
 */
function appex_commands_remove(array $files, array $mu_files)
{
	$trash = WP_CONTENT_DIR . '/upgrade/' . APPEX_COMMANDS_TRASH_PREFIX . wp_generate_password(12, false);
	if (!wp_mkdir_p($trash)) {
		return new WP_Error('appex_command_filesystem', 'Could not create a folder in wp-content/upgrade.', ['status' => 500]);
	}
	appex_commands_close_to_web($trash);

	foreach ($files as $file) {
		// Its uninstall routine, as when deleting it in WP Admin.
		if (is_uninstallable_plugin($file)) {
			uninstall_plugin($file);
		}
		do_action('delete_plugin', $file);
		// A plain rename, never WordPress's copy-then-delete fallback, which could stop halfway.
		$dir = WP_PLUGIN_DIR . '/' . dirname($file);
		$moved = @rename($dir, $trash . '/' . basename($dir));
		do_action('deleted_plugin', $file, $moved);
		if (!$moved) {
			return new WP_Error('appex_command_move_failed', 'Could not move ' . dirname($file) . ' out of the plugins folder; its files are untouched.', ['status' => 500]);
		}
	}
	wp_clean_plugins_cache(false);

	// Must-use files are moved too: WordPress only loads .php files directly in mu-plugins.
	foreach ($mu_files as $mu) {
		if (is_file(WPMU_PLUGIN_DIR . '/' . $mu) && !@rename(WPMU_PLUGIN_DIR . '/' . $mu, $trash . '/' . $mu)) {
			return new WP_Error('appex_command_move_failed', 'Could not move mu-plugins/' . $mu . ' out of the way.', ['status' => 500]);
		}
	}

	return true;
}

// Refuses web requests for anything in a folder of removed files (Apache, which serves PHP on WP Engine).
function appex_commands_close_to_web($dir)
{
	@file_put_contents($dir . '/.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n");
}

// Deletes removed plugin folders. Also catches up on any an earlier request didn't get to.
function appex_commands_empty_trash()
{
	global $wp_filesystem;
	$dirs = glob(WP_CONTENT_DIR . '/upgrade/' . APPEX_COMMANDS_TRASH_PREFIX . '*', GLOB_ONLYDIR) ?: [];
	if (!$dirs) {
		return;
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	if (!$wp_filesystem && !WP_Filesystem()) {
		return;
	}
	foreach ($dirs as $dir) {
		$wp_filesystem->delete($dir, true);
		// What's left (.php files on WP Engine) stays closed to the web; deleting took the .htaccess.
		clearstatcache();
		if (is_dir($dir)) {
			appex_commands_close_to_web($dir);
		}
	}
}

add_action('appex_commands_empty_trash', 'appex_commands_empty_trash');

// Runs once the answer is out: removed files are deleted by WP-Cron (see the top of this file),
// started right away rather than at the next visit. The dashboard also requests wp-cron.php.
function appex_commands_after_response()
{
	if (!glob(WP_CONTENT_DIR . '/upgrade/' . APPEX_COMMANDS_TRASH_PREFIX . '*', GLOB_ONLYDIR)) {
		return;
	}
	if (!wp_next_scheduled('appex_commands_empty_trash')) {
		wp_schedule_single_event(time(), 'appex_commands_empty_trash');
	}
	spawn_cron();
}

add_action('appex_commands_update_self', 'appex_commands_update_self');

// The Appex plugins installed here and active, by main file.
function appex_commands_self_files()
{
	$files = [];
	foreach (get_plugins() as $file => $data) {
		if (isset(APPEX_COMMANDS_SELF[basename($file)]) && is_plugin_active($file)) {
			$files[] = $file;
		}
	}
	return $files;
}

function appex_commands_self_report()
{
	wp_clean_plugins_cache(false);
	$plugins = get_plugins();
	return array_map(function ($file) use ($plugins) {
		return ['slug' => dirname($file), 'name' => $plugins[$file]['Name'], 'version' => $plugins[$file]['Version'], 'active' => true];
	}, appex_commands_self_files());
}

/**
 * Hands the update to WP-Cron and starts it, so it runs like WordPress's own background updates:
 * the plugin stays active, and the old files can be deleted on WP Engine.
 *
 * @return true|WP_Error
 */
function appex_commands_schedule_update()
{
	if (!appex_commands_self_files()) {
		return new WP_Error('appex_command_invalid', 'No active Appex plugin to update.', ['status' => 400]);
	}
	if (!wp_next_scheduled('appex_commands_update_self')) {
		wp_schedule_single_event(time(), 'appex_commands_update_self');
	}
	spawn_cron();
	return true;
}

// The update itself, in WP-Cron. The result is kept for the status (selfUpdate).
function appex_commands_update_self()
{
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

	$results = [];
	foreach (appex_commands_self_files() as $file) {
		$results[dirname($file)] = appex_commands_update_one($file, APPEX_COMMANDS_SELF[basename($file)]);
	}
	update_site_option('appex_commands_self_update', ['at' => gmdate('c'), 'results' => $results]);
}

// Updates one Appex plugin to the version its feed offers. Returns what happened, for the status.
function appex_commands_update_one($file, array $self)
{
	$installed = get_plugins()[$file]['Version'] ?? '0';
	// The query string gets past caches in front of the feed.
	$response = wp_remote_get(add_query_arg('t', time(), $self['feed']), ['timeout' => 15]);
	$info = json_decode(wp_remote_retrieve_body($response), true);
	if (is_wp_error($response) || empty($info['version']) || empty($info['download_url'])) {
		return 'could not read the update feed';
	}
	if (strpos($info['download_url'], $self['packages']) !== 0) {
		return 'the feed offered a package from elsewhere';
	}
	if (version_compare($info['version'], $installed, '<=')) {
		return "up to date ($installed)";
	}

	// Offer it to WordPress's updater, as the plugin's update checker does.
	$offer = function ($transient) use ($file, $info) {
		if (!is_object($transient)) {
			$transient = new stdClass();
		}
		$transient->response[$file] = (object) [
			'slug' => dirname($file),
			'plugin' => $file,
			'new_version' => $info['version'],
			'package' => $info['download_url'],
			'url' => '',
		];
		return $transient;
	};
	add_filter('site_transient_update_plugins', $offer, PHP_INT_MAX);
	$upgrader = new Plugin_Upgrader(new Automatic_Upgrader_Skin());
	$result = $upgrader->upgrade($file);
	remove_filter('site_transient_update_plugins', $offer, PHP_INT_MAX);

	if (is_wp_error($result)) {
		return 'failed: ' . $result->get_error_message();
	}
	if (!$result) {
		return 'failed: ' . wp_strip_all_tags(html_entity_decode(implode(' ', $upgrader->skin->get_upgrade_messages())));
	}
	return "updated $installed → {$info['version']}";
}

function appex_commands_handle(WP_REST_Request $request)
{
	$params = $request->get_json_params() ?: [];
	$action = $params['action'] ?? '';
	$group_name = $params['group'] ?? '';
	$group = APPEX_COMMANDS_GROUPS[$group_name] ?? null;
	$self_update = $action === 'update' && $group_name === 'appex';
	if (!$self_update && (!$group || !in_array($action, ['enable', 'disable', 'remove'], true))) {
		return new WP_Error('appex_command_invalid', 'Unknown action or plugin group.', ['status' => 400]);
	}

	require_once ABSPATH . 'wp-admin/includes/plugin.php';
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

	// One action per group at a time, with WordPress's own upgrade lock (an atomic insert). It
	// expires by itself if PHP dies halfway.
	$lock = 'appex_cmd_' . $group_name;
	if (!WP_Upgrader::create_lock($lock, 120)) {
		return new WP_Error('appex_command_busy', 'Another action on this plugin is still running on the site. Try again in a minute.', ['status' => 409]);
	}

	// Finish what was started even if the dashboard stops waiting.
	ignore_user_abort(true);
	if (function_exists('set_time_limit')) {
		@set_time_limit(120);
	}
	register_shutdown_function('appex_commands_after_response');

	try {
		$result = $self_update ? appex_commands_schedule_update() : appex_commands_run($action, $group, $params);
	} finally {
		WP_Upgrader::release_lock($lock);
	}
	if (is_wp_error($result)) {
		return $result;
	}

	$response = rest_ensure_response($self_update
		? ['plugins' => appex_commands_self_report(), 'scheduled' => true]
		: ['plugins' => appex_commands_report($group)]);
	$response->header('Cache-Control', 'no-store, private');
	return $response;
}

/**
 * @return true|WP_Error
 */
function appex_commands_run($action, array $group, array $params)
{
	if ($action === 'enable') {
		if (!array_key_exists($group['main'], get_plugins())) {
			$installed = appex_commands_install($group, $params['package'] ?? null);
			if (is_wp_error($installed)) {
				return $installed;
			}
		}
		// Network-wide on multisites, which is how WP Migrate runs there. Runs its activation hook.
		$activated = activate_plugin($group['main'], '', is_multisite());
		return is_wp_error($activated) ? $activated : true;
	}

	$files = appex_commands_files($group);
	// null: deactivates network-wide where it's network-active, and on this site where it's active here.
	deactivate_plugins($files, false, null);
	if ($action === 'disable') {
		return true;
	}

	$mu_files = array_values(array_filter($group['mu'], function ($mu) {
		return is_file(WPMU_PLUGIN_DIR . '/' . $mu);
	}));
	if ($files || $mu_files) {
		$removed = appex_commands_remove($files, $mu_files);
		if (is_wp_error($removed)) {
			return $removed;
		}
	}
	return true;
}
