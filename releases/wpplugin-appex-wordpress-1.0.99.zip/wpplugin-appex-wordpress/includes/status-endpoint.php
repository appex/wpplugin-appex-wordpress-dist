<?php
/**
 * Read-only status endpoint for the WebCare dashboard: GET /wp-json/appex/v1/status
 *
 * Reports WordPress, PHP, theme and plugin versions plus available updates, using the
 * update data WordPress already keeps. Loaded before the ACF check in appex-wordpress.php
 * so it keeps reporting on sites where ACF is broken.
 *
 * Requests must be signed by the dashboard with Ed25519. Only public keys live here, so
 * nothing secret ships with the plugin. The signed message is "<timestamp>\n<route>" and
 * signatures are accepted for 5 minutes.
 */

if (!defined('ABSPATH')) {
	exit;
}

// Base64-encoded Ed25519 public keys allowed to read the status. Add a new key here before
// rotating the dashboard's private key, then remove the old one.
const APPEX_STATUS_PUBLIC_KEYS = [
	'YDugbg2hJitRFSvT2soFFcOok/KJ07si+u/JIL6uK8E=',
];

const APPEX_STATUS_MAX_CLOCK_SKEW = 300;

add_action('rest_api_init', function () {
	register_rest_route('appex/v1', '/status', [
		'methods' => 'GET',
		'callback' => 'appex_status_response',
		'permission_callback' => 'appex_status_verify_request',
	]);
});

function appex_status_verify_request(WP_REST_Request $request)
{
	return appex_status_verify(
		$request->get_header('x_appex_timestamp'),
		$request->get_header('x_appex_signature'),
		$request->get_route()
	);
}

// Some sites run security plugins that block the REST API for logged-out visitors through
// this filter. Let correctly signed status requests through; everything else is untouched.
add_filter('rest_authentication_errors', function ($result) {
	if (!is_wp_error($result)) {
		return $result;
	}

	$route = untrailingslashit($GLOBALS['wp']->query_vars['rest_route'] ?? '');
	if ($route !== '/appex/v1/status') {
		return $result;
	}

	$verified = appex_status_verify(
		$_SERVER['HTTP_X_APPEX_TIMESTAMP'] ?? null,
		$_SERVER['HTTP_X_APPEX_SIGNATURE'] ?? null,
		$route
	);

	return $verified === true ? true : $result;
}, PHP_INT_MAX);

/**
 * @return true|WP_Error
 */
function appex_status_verify($timestamp, $signature_b64, $route)
{
	$signature = base64_decode((string) $signature_b64, true);

	if (!ctype_digit((string) $timestamp) || abs(time() - (int) $timestamp) > APPEX_STATUS_MAX_CLOCK_SKEW) {
		return new WP_Error('appex_status_expired', 'Missing or expired timestamp.', ['status' => 401]);
	}
	if ($signature === false || strlen($signature) !== 64) {
		return new WP_Error('appex_status_unsigned', 'Missing or malformed signature.', ['status' => 401]);
	}

	// PHP's sodium extension is optional; WordPress bundles a polyfill.
	if (!function_exists('sodium_crypto_sign_verify_detached')) {
		require_once ABSPATH . WPINC . '/sodium_compat/autoload.php';
	}

	$message = $timestamp . "\n" . $route;
	foreach (APPEX_STATUS_PUBLIC_KEYS as $key) {
		if (sodium_crypto_sign_verify_detached($signature, $message, base64_decode($key))) {
			return true;
		}
	}

	return new WP_Error('appex_status_forbidden', 'Invalid signature.', ['status' => 401]);
}

function appex_status_response()
{
	global $wp_version;

	require_once ABSPATH . 'wp-admin/includes/plugin.php';

	$plugin_updates = get_site_transient('update_plugins');
	$plugins = [];
	foreach (get_plugins() as $file => $data) {
		$plugins[] = [
			'slug' => dirname($file) === '.' ? basename($file, '.php') : dirname($file),
			'name' => $data['Name'],
			'version' => $data['Version'],
			'active' => is_plugin_active($file),
			'update' => $plugin_updates->response[$file]->new_version ?? null,
		];
	}

	$core_update = null;
	foreach (get_site_transient('update_core')->updates ?? [] as $offer) {
		if (($offer->response ?? '') === 'upgrade') {
			$core_update = $offer->current;
			break;
		}
	}

	$theme = wp_get_theme();
	$theme_updates = get_site_transient('update_themes');

	$response = rest_ensure_response([
		'appexVersion' => get_file_data(dirname(__DIR__) . '/appex-wordpress.php', ['Version' => 'Version'])['Version'],
		'wordpress' => ['version' => $wp_version, 'update' => $core_update],
		'php' => PHP_VERSION,
		'theme' => [
			'name' => $theme->get('Name'),
			'version' => $theme->get('Version'),
			'update' => $theme_updates->response[$theme->get_stylesheet()]['new_version'] ?? null,
		],
		'plugins' => $plugins,
		// When WordPress last checked for plugin updates; null if it never has.
		'checkedAt' => isset($plugin_updates->last_checked) ? gmdate('c', $plugin_updates->last_checked) : null,
	]);
	$response->header('Cache-Control', 'no-store, private');

	return $response;
}
